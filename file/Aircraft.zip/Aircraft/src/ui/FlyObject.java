package ui;

import java.awt.image.BufferedImage;

//具有共同特点，故抽离成父类
public class FlyObject {

    BufferedImage img;
    int x;
    int y;
    int w;
    int h;


}

