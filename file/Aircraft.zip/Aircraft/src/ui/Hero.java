package ui;

import java.awt.image.BufferedImage;

//主机
public class Hero extends FlyObject{
    //主机血量
    int hp;

    public Hero(){
        img = App.getImg("/res/hero.png");
        //确认初始位置
        x = 200;
        y = 500;
        w = img.getWidth();
        h = img.getHeight();
        hp = 3;
    }

    public void moveToMouse(int mx,int my){
        x = mx;
        y = my;
    }
    public boolean shootBy(EpFire f) {
        Boolean hit = (f.x>=x&&f.x<=x+w)&&(f.y>=y&&f.y<=y+h);
        if(hit){
            hp--;
        }
        return hit;
    }
}
