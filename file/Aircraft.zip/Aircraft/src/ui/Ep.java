package ui;

import javax.swing.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//敌机类
public class Ep extends FlyObject{
    int sp;
    //设置敌机类型
    int type;
    int hp = 1;

    int flag = 0;

    public Ep(){

        Random random = new Random();
        int index = random.nextInt(7)+1;
        type = index;
        String path = "/res/img-plane_"+index+".png";
        img = App.getImg(path);

        //确定敌机图片
        w = img.getWidth();
        x = random.nextInt(512-w);
        y = 0;

        //设置速度
        sp = 4 - index / 2;


    }
    public Ep(String path){

        Random random = new Random();
        img = App.getImg(path);

        //确定敌机图片
        w = img.getWidth();
        x = random.nextInt(512-w);
        y = 0;

        //设置速度
        sp = 2;


    }

    public void move() {

        //普通飞机移动
        if(hp < 2 || y <= 100){
            if(type==5){
                x -= 2;
                y += sp;
            }
            else if(type==6){
                x += 2;
                y += sp;
            }
            else {
                y+=sp;
            }
        }


        //用血量来定位boss;
        //boss特殊移动方式
        if(hp > 2 && x >= 0 - w && x < 512 && y > 100){
            flag++;
            if(flag%200 <= 40){
                x -= 3;
            }
            else if(flag%200 <= 90){
                y += 3;
            }
            else if(flag%200 <= 140){
                x += 3;
            }
            else if(flag%200 <= 190){
                y -= 3;
            }
        }
    }

    public boolean shootBy(Fire f) {
        Boolean hit = x <= f.x+f.w &&x>f.x-w&&y<=f.y+f.h&&y>f.y-h;
        if(hit){
            hp--;
        }
        return hit;
    }

    public boolean shootBy(Hero f) {
        Boolean hit = x <= f.x+f.w &&x>f.x-w&&y<=f.y+f.h&&y>f.y-h;
        if(hit){
            hp--;
        }
        return hit;
    }
}

