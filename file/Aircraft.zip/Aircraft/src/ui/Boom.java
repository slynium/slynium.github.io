package ui;

public class Boom extends FlyObject{

    public Boom(Ep e){
        //确定子弹的图片
        img = App.getImg("/res/bomb-1.png");
        //确定图片的大小
        w = img.getWidth();
        h = img.getHeight();
        //确定子弹的位置
        x = e.x;
        y = e.y;
    }
}
