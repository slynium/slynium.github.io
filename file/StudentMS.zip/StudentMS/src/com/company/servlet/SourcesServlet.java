package com.company.servlet;

import com.company.beans.entity.CustomerDO;
import com.company.beans.req.CustomerRequest;
import com.company.beans.res.TableResult;
import com.company.service.CustomerService;
import com.company.service.impl.CustomerServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "SourcesServlet", urlPatterns = "/SourcesServlet")
public class SourcesServlet extends HttpServlet {
    private CustomerService customerService = new CustomerServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");
        if(type.equals("toSourcesManager")){
            CustomerRequest customerRequest = new CustomerRequest();

            String pageNowStr = request.getParameter("pageNow");
            String customerName = request.getParameter("C_NAME");
            //默认查询第一页
            int pageNow = 1;
            if(pageNowStr != null && !pageNowStr.trim().equals("")){
                pageNow = Integer.parseInt(pageNowStr);
            }
            customerRequest.setPageNow(pageNow);
            customerRequest.setCustomerName(customerName);

            TableResult<CustomerDO> tableResult = customerService.queryCustomerByPage(customerRequest);
            tableResult.setPageNow(pageNow);
            tableResult.setKeyWord(customerName == null ? "" : customerName);

            //放到request的请求域中,并在sourcesManager中使用
            request.setAttribute("tableResult", tableResult);
            request.getRequestDispatcher("/WEB-INF/sources/sourcesManager.jsp").forward(request, response);
        }
        else if (type.equals("toCustomerAdd")){
            request.getRequestDispatcher("/WEB-INF/sources/customerAdd.jsp").forward(request, response);
        }
        else if (type.equals("add")){
            //执行添加
            int C_CUSTKEY = Integer.parseInt(request.getParameter("C_CUSTKEY"));
            String C_NAME = request.getParameter("C_NAME");
            String C_ADDRESS = request.getParameter("C_ADDRESS");
            int C_NATIONKEY = Integer.parseInt(request.getParameter("C_NATIONKEY"));
            String C_PHONE = request.getParameter("C_PHONE");
            String C_ACCTBAL = request.getParameter("C_ACCTBAL");
            String C_MKTSEGMENT = request.getParameter("C_MKTSEGMENT");
            String C_COMMENT = request.getParameter("C_COMMENT");



            CustomerDO customerDO = new CustomerDO();

            customerDO.setC_CUSTKEY(C_CUSTKEY);
            customerDO.setC_NAME(C_NAME);
            customerDO.setC_ADDRESS(C_ADDRESS);
            customerDO.setC_NATIONKEY(C_NATIONKEY);
            customerDO.setC_PHONE(C_PHONE);
            customerDO.setC_ACCTBAL(C_ACCTBAL);
            customerDO.setC_MKTSEGMENT(C_MKTSEGMENT);
            customerDO.setC_COMMENT(C_COMMENT);

            customerService.addCustomer(customerDO);


            //转发回首页
            response.sendRedirect(request.getContextPath() + "/SourcesServlet?type=toSourcesManager");

        }
        else if(type.equals("toUpdate")){
            String C_CUSTKEY = request.getParameter("C_CUSTKEY");
            String pageNow = request.getParameter("pageNow");
            String customerName = request.getParameter("customerName");
            CustomerDO customerDO =  customerService.getCustomerByC_CUSTKEY(Integer.parseInt(C_CUSTKEY));
            //放入请求域中
            request.setAttribute("customerDO", customerDO);
            request.setAttribute("pageNow", Integer.parseInt(pageNow));
            request.setAttribute("customerName", customerName);

            request.getRequestDispatcher("/WEB-INF/sources/customerUpdate.jsp").forward(request, response);
        }
        else if (type.equals("update")){
            int C_CUSTKEY = Integer.parseInt(request.getParameter("C_CUSTKEY"));
            String C_NAME = request.getParameter("C_NAME");
            String C_ADDRESS = request.getParameter("C_ADDRESS");
            int C_NATIONKEY = Integer.parseInt(request.getParameter("C_NATIONKEY"));
            String C_PHONE = request.getParameter("C_PHONE");
            String C_ACCTBAL = request.getParameter("C_ACCTBAL");
            String C_MKTSEGMENT = request.getParameter("C_MKTSEGMENT");
            String C_COMMENT = request.getParameter("C_COMMENT");

            String pageNow = request.getParameter("pageNow");
            String customerName = request.getParameter("customerName");

            CustomerDO customerDO = new CustomerDO();

            customerDO.setC_CUSTKEY(C_CUSTKEY);
            customerDO.setC_NAME(C_NAME);
            customerDO.setC_ADDRESS(C_ADDRESS);
            customerDO.setC_NATIONKEY(C_NATIONKEY);
            customerDO.setC_PHONE(C_PHONE);
            customerDO.setC_ACCTBAL(C_ACCTBAL);
            customerDO.setC_MKTSEGMENT(C_MKTSEGMENT);
            customerDO.setC_COMMENT(C_COMMENT);

            customerService.updateCustomer(customerDO);

            //转发回首页
            response.sendRedirect(request.getContextPath() + "/SourcesServlet?type=toSourcesManager&pageNow=" + pageNow + "&C_NAME=" + customerName);
        }
        else if (type.equals("delete")){
            int C_CUSTKEY = Integer.parseInt(request.getParameter("C_CUSTKEY"));

            String pageNow = request.getParameter("pageNow");
            String customerName = request.getParameter("customerName");


            customerService.deleteCustomer(C_CUSTKEY);

            //转发回首页
            response.sendRedirect(request.getContextPath() + "/SourcesServlet?type=toSourcesManager&pageNow=" + pageNow + "&C_NAME=" + customerName);

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }
}
