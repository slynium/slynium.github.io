package com.company.servlet;

import com.company.beans.entity.OrderDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.service.OrderService;
import com.company.service.SupplierService;
import com.company.service.impl.OrderServiceImpl;
import com.company.service.impl.SupplierServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "SupplierServlet", value = "/SupplierServlet")
public class SupplierServlet extends HttpServlet {
    private SupplierService supplierService = new SupplierServiceImpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");
        if(type.equals("toSupplierManager")){
            QueryRequest queryRequest = new QueryRequest();

            String pageNowStr = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            //默认查询第一页
            int pageNow = 1;
            if(pageNowStr != null && !pageNowStr.trim().equals("")){
                pageNow = Integer.parseInt(pageNowStr);
            }
            queryRequest.setPageNow(pageNow);
            queryRequest.setKeyword(keyword);

            TableResult<SupplierDO> tableResult = supplierService.querySupplierByPage(queryRequest);
            tableResult.setPageNow(pageNow);
            tableResult.setKeyWord(keyword == null ? "" : keyword);

            //放到request的请求域中,并在sourcesManager中使用
            request.setAttribute("tableResult", tableResult);
            request.getRequestDispatcher("/WEB-INF/sources/supplierManager.jsp").forward(request, response);
        }
        else if (type.equals("toSupplierAdd")){
            request.getRequestDispatcher("/WEB-INF/sources/supplierAdd.jsp").forward(request, response);
        }
        else if (type.equals("add")){
            //执行添加
            String S_SUPPKEY = request.getParameter("S_SUPPKEY");
            String S_NAME = request.getParameter("S_NAME");
            String S_ADDRESS = request.getParameter("S_ADDRESS");
            String S_NATIONKEY = request.getParameter("S_NATIONKEY");
            String S_PHONE = request.getParameter("S_PHONE");
            String S_ACCTBAL = request.getParameter("S_ACCTBAL");
            String S_COMMENT = request.getParameter("S_COMMENT");


            SupplierDO supplierDO = new SupplierDO();

            supplierDO.setS_SUPPKEY(S_SUPPKEY);
            supplierDO.setS_NAME(S_NAME);
            supplierDO.setS_ADDRESS(S_ADDRESS);
            supplierDO.setS_NATIONKEY(S_NATIONKEY);
            supplierDO.setS_PHONE(S_PHONE);
            supplierDO.setS_ACCTBAL(S_ACCTBAL);
            supplierDO.setS_COMMENT(S_COMMENT);

            supplierService.addSupplier(supplierDO);


            //转发回首页
            response.sendRedirect(request.getContextPath() + "/SupplierServlet?type=toSupplierManager");

        }
        else if(type.equals("toUpdate")){
            String S_SUPPKEY = request.getParameter("S_SUPPKEY");
            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            SupplierDO supplierDO =  supplierService.getSupplierByS_SUPPKEY(Integer.parseInt(S_SUPPKEY));
            //放入请求域中
            request.setAttribute("SupplierDO", supplierDO);
            request.setAttribute("pageNow", Integer.parseInt(pageNow));
            request.setAttribute("keyword", keyword);

            request.getRequestDispatcher("/WEB-INF/sources/supplierUpdate.jsp").forward(request, response);
        }
        else if (type.equals("update")){
            String S_SUPPKEY = request.getParameter("S_SUPPKEY");
            String S_NAME = request.getParameter("S_NAME");
            String S_ADDRESS = request.getParameter("S_ADDRESS");
            String S_NATIONKEY = request.getParameter("S_NATIONKEY");
            String S_PHONE = request.getParameter("S_PHONE");
            String S_ACCTBAL = request.getParameter("S_ACCTBAL");
            String S_COMMENT = request.getParameter("S_COMMENT");


            SupplierDO supplierDO = new SupplierDO();

            supplierDO.setS_SUPPKEY(S_SUPPKEY);
            supplierDO.setS_NAME(S_NAME);
            supplierDO.setS_ADDRESS(S_ADDRESS);
            supplierDO.setS_NATIONKEY(S_NATIONKEY);
            supplierDO.setS_PHONE(S_PHONE);
            supplierDO.setS_ACCTBAL(S_ACCTBAL);
            supplierDO.setS_COMMENT(S_COMMENT);

            supplierService.updateSupplier(supplierDO);



            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");



            //转发回首页
            response.sendRedirect(request.getContextPath() + "/SupplierServlet?type=toSupplierManager&pageNow=" + pageNow + "&keyword=" + keyword);
        }

        else if (type.equals("delete")){
            int S_SUPPKEY = Integer.parseInt(request.getParameter("S_SUPPKEY"));

            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");


            supplierService.deleteSupplier(S_SUPPKEY);

            //转发回首页
            response.sendRedirect(request.getContextPath() + "/SupplierServlet?type=toSupplierManager&pageNow=" + pageNow + "&keyword=" + keyword);

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }
}
