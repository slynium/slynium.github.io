package com.company.servlet;

import com.company.beans.entity.PartsuppDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.service.PartsuppService;
import com.company.service.SupplierService;
import com.company.service.impl.PartsuppServiceImpl;
import com.company.service.impl.SupplierServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "PartsuppServlet", value = "/PartsuppServlet")
public class PartsuppServlet extends HttpServlet {
    private PartsuppService partsuppService = new PartsuppServiceImpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");
        if(type.equals("toPartsuppManager")){
            QueryRequest queryRequest = new QueryRequest();

            String pageNowStr = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            //默认查询第一页
            int pageNow = 1;
            if(pageNowStr != null && !pageNowStr.trim().equals("")){
                pageNow = Integer.parseInt(pageNowStr);
            }
            queryRequest.setPageNow(pageNow);
            queryRequest.setKeyword(keyword);

            TableResult<PartsuppDO> tableResult = partsuppService.queryPartsuppByPage(queryRequest);
            tableResult.setPageNow(pageNow);
            tableResult.setKeyWord(keyword == null ? "" : keyword);

            //放到request的请求域中,并在sourcesManager中使用
            request.setAttribute("tableResult", tableResult);
            request.getRequestDispatcher("/WEB-INF/sources/partsuppManager.jsp").forward(request, response);
        }
        else if (type.equals("toPartsuppAdd")){
            request.getRequestDispatcher("/WEB-INF/sources/partsuppAdd.jsp").forward(request, response);
        }
        else if (type.equals("add")){
            //执行添加
            String PS_PARTKEY = request.getParameter("PS_PARTKEY");
            String PS_SUPPKEY = request.getParameter("PS_SUPPKEY");
            String PS_AVAILQTY = request.getParameter("PS_AVAILQTY");
            String PS_SUPPLYCOST = request.getParameter("PS_SUPPLYCOST");
            String PS_COMMENT = request.getParameter("PS_COMMENT");


            PartsuppDO partsuppDO = new PartsuppDO();

            partsuppDO.setPS_PARTKEY(PS_PARTKEY);
            partsuppDO.setPS_SUPPKEY(PS_SUPPKEY);
            partsuppDO.setPS_AVAILQTY(PS_AVAILQTY);
            partsuppDO.setPS_SUPPLYCOST(PS_SUPPLYCOST);
            partsuppDO.setPS_COMMENT(PS_COMMENT);

            partsuppService.addPartsupp(partsuppDO);


            //转发回首页
            response.sendRedirect(request.getContextPath() + "/PartsuppServlet?type=toPartsuppManager");

        }
        else if(type.equals("toUpdate")){
            String PS_PARTKEY = request.getParameter("PS_PARTKEY");
            String PS_SUPPKEY = request.getParameter("PS_SUPPKEY");
            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            PartsuppDO partsuppDO =  partsuppService.getPartsuppByPS_PARTKEYAndPS_SUPPKEY(Integer.parseInt(PS_PARTKEY),Integer.parseInt(PS_SUPPKEY));
            //放入请求域中
            request.setAttribute("PartsuppDO", partsuppDO);
            request.setAttribute("pageNow", Integer.parseInt(pageNow));
            request.setAttribute("keyword", keyword);

            request.getRequestDispatcher("/WEB-INF/sources/partsuppUpdate.jsp").forward(request, response);
        }
        else if (type.equals("update")){
            String PS_PARTKEY = request.getParameter("PS_PARTKEY");
            String PS_SUPPKEY = request.getParameter("PS_SUPPKEY");
            String PS_AVAILQTY = request.getParameter("PS_AVAILQTY");
            String PS_SUPPLYCOST = request.getParameter("PS_SUPPLYCOST");
            String PS_COMMENT = request.getParameter("PS_COMMENT");


            PartsuppDO partsuppDO = new PartsuppDO();

            partsuppDO.setPS_PARTKEY(PS_PARTKEY);
            partsuppDO.setPS_SUPPKEY(PS_SUPPKEY);
            partsuppDO.setPS_AVAILQTY(PS_AVAILQTY);
            partsuppDO.setPS_SUPPLYCOST(PS_SUPPLYCOST);
            partsuppDO.setPS_COMMENT(PS_COMMENT);

            partsuppService.updatePartsupp(partsuppDO);



            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");



            //转发回首页
            response.sendRedirect(request.getContextPath() + "/PartsuppServlet?type=toPartsuppManager&pageNow=" + pageNow + "&keyword=" + keyword);
        }

        else if (type.equals("delete")){
            int PS_PARTKEY = Integer.parseInt(request.getParameter("PS_PARTKEY"));
            int PS_SUPPKEY = Integer.parseInt(request.getParameter("PS_SUPPKEY"));

            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");


            partsuppService.deletePartsupp(PS_PARTKEY,PS_SUPPKEY);

            //转发回首页
            response.sendRedirect(request.getContextPath() + "/PartsuppServlet?type=toPartsuppManager&pageNow=" + pageNow + "&keyword=" + keyword);

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }
}
