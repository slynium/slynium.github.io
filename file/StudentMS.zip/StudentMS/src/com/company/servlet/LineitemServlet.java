package com.company.servlet;

import com.company.beans.entity.LineitemDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.service.LineitemService;
import com.company.service.RegionService;
import com.company.service.impl.LineitemServiceImpl;
import com.company.service.impl.RegionServiceImpl;
import com.company.util.StringUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "LineitemServlet", value = "/LineitemServlet")
public class LineitemServlet extends HttpServlet {
    private LineitemService lineitemService = new LineitemServiceImpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");
        if(type.equals("toLineitemManager")){
            QueryRequest queryRequest = new QueryRequest();

            String L_ORDERKEY = request.getParameter("O_ORDERKEY");
            String pageNowStr = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            //默认查询第一页
            int pageNow = 1;
            if(pageNowStr != null && !pageNowStr.trim().equals("")){
                pageNow = Integer.parseInt(pageNowStr);
            }
            queryRequest.setPageNow(pageNow);
            queryRequest.setKeyword(keyword);
            if(StringUtil.isNotBlank(L_ORDERKEY)){
                queryRequest.setKeyword(L_ORDERKEY);
            }

            TableResult<LineitemDO> tableResult = lineitemService.queryLineitemByPage(queryRequest);
            tableResult.setPageNow(pageNow);
            tableResult.setKeyWord(keyword == null ? "" : keyword);

            //放到request的请求域中,并在sourcesManager中使用
            request.setAttribute("tableResult", tableResult);
            request.getRequestDispatcher("/WEB-INF/sources/lineitemManager.jsp").forward(request, response);
        }
        else if (type.equals("toLineitemAdd")){
            String keyword = request.getParameter("keyword");

            request.setAttribute("keyword", keyword);
            request.getRequestDispatcher("/WEB-INF/sources/lineitemAdd.jsp").forward(request, response);
        }
        else if (type.equals("add")){
            //执行添加
            String L_ORDERKEY = request.getParameter("L_ORDERKEY");
            String L_PARTKEY = request.getParameter("L_PARTKEY");
            String L_SUPPKEY = request.getParameter("L_SUPPKEY");
            String L_LINENUMBER = request.getParameter("L_LINENUMBER");
            String L_QUANTITY = request.getParameter("L_QUANTITY");
            String L_EXTENDEDPRICE = request.getParameter("L_EXTENDEDPRICE");
            String L_DISCOUNT = request.getParameter("L_DISCOUNT");
            String L_TAX = request.getParameter("L_TAX");
            String L_RETURNFLAG = request.getParameter("L_RETURNFLAG");
            String L_LINESTATUS = request.getParameter("L_LINESTATUS");
            String L_SHIPDATE = request.getParameter("L_SHIPDATE");
            String L_COMMITDATE = request.getParameter("L_COMMITDATE");
            String L_RECEIPTDATE = request.getParameter("L_RECEIPTDATE");
            String L_SHIPINSTRUCT = request.getParameter("L_SHIPINSTRUCT");
            String L_SHIPMODE = request.getParameter("L_SHIPMODE");
            String L_COMMENT = request.getParameter("L_COMMENT");

            LineitemDO lineitemDO = new LineitemDO();

            lineitemDO.setL_ORDERKEY(L_ORDERKEY);
            lineitemDO.setL_PARTKEY(L_PARTKEY);
            lineitemDO.setL_SUPPKEY(L_SUPPKEY);
            lineitemDO.setL_LINENUMBER(L_LINENUMBER);
            lineitemDO.setL_QUANTITY(L_QUANTITY);
            lineitemDO.setL_EXTENDEDPRICE(L_EXTENDEDPRICE);
            lineitemDO.setL_DISCOUNT(L_DISCOUNT);
            lineitemDO.setL_TAX(L_TAX);
            lineitemDO.setL_RETURNFLAG(L_RETURNFLAG);
            lineitemDO.setL_LINESTATUS(L_LINESTATUS);
            lineitemDO.setL_SHIPDATE(L_SHIPDATE);
            lineitemDO.setL_COMMITDATE(L_COMMITDATE);
            lineitemDO.setL_RECEIPTDATE(L_RECEIPTDATE);
            lineitemDO.setL_SHIPINSTRUCT(L_SHIPINSTRUCT);
            lineitemDO.setL_SHIPMODE(L_SHIPMODE);
            lineitemDO.setL_COMMENT(L_COMMENT);


            lineitemService.addLineitem(lineitemDO);


            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            //转发回首页
            response.sendRedirect(request.getContextPath() + "/LineitemServlet?type=toLineitemManager&pageNow=" + pageNow + "&keyword=" + keyword);

        }
        else if(type.equals("toUpdate")){
            String L_ORDERKEY = request.getParameter("L_ORDERKEY");
            String L_LINENUMBER = request.getParameter("L_LINENUMBER");
            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            LineitemDO lineitemDO =  lineitemService.getLineitemByL_ORDERKEYAndL_LINENUMBER(Integer.parseInt(L_ORDERKEY), Integer.parseInt(L_LINENUMBER));
            //放入请求域中
            request.setAttribute("LineitemDO", lineitemDO);
            request.setAttribute("pageNow", Integer.parseInt(pageNow));
            request.setAttribute("keyword", keyword);

            request.getRequestDispatcher("/WEB-INF/sources/lineitemUpdate.jsp").forward(request, response);
        }
        else if (type.equals("update")){
            String L_ORDERKEY = request.getParameter("L_ORDERKEY");
            String L_PARTKEY = request.getParameter("L_PARTKEY");
            String L_SUPPKEY = request.getParameter("L_SUPPKEY");
            String L_LINENUMBER = request.getParameter("L_LINENUMBER");
            String L_QUANTITY = request.getParameter("L_QUANTITY");
            String L_EXTENDEDPRICE = request.getParameter("L_EXTENDEDPRICE");
            String L_DISCOUNT = request.getParameter("L_DISCOUNT");
            String L_TAX = request.getParameter("L_TAX");
            String L_RETURNFLAG = request.getParameter("L_RETURNFLAG");
            String L_LINESTATUS = request.getParameter("L_LINESTATUS");
            String L_SHIPDATE = request.getParameter("L_SHIPDATE");
            String L_COMMITDATE = request.getParameter("L_COMMITDATE");
            String L_RECEIPTDATE = request.getParameter("L_RECEIPTDATE");
            String L_SHIPINSTRUCT = request.getParameter("L_SHIPINSTRUCT");
            String L_SHIPMODE = request.getParameter("L_SHIPMODE");
            String L_COMMENT = request.getParameter("L_COMMENT");

            LineitemDO lineitemDO = new LineitemDO();

            lineitemDO.setL_ORDERKEY(L_ORDERKEY);
            lineitemDO.setL_PARTKEY(L_PARTKEY);
            lineitemDO.setL_SUPPKEY(L_SUPPKEY);
            lineitemDO.setL_LINENUMBER(L_LINENUMBER);
            lineitemDO.setL_QUANTITY(L_QUANTITY);
            lineitemDO.setL_EXTENDEDPRICE(L_EXTENDEDPRICE);
            lineitemDO.setL_DISCOUNT(L_DISCOUNT);
            lineitemDO.setL_TAX(L_TAX);
            lineitemDO.setL_RETURNFLAG(L_RETURNFLAG);
            lineitemDO.setL_LINESTATUS(L_LINESTATUS);
            lineitemDO.setL_SHIPDATE(L_SHIPDATE);
            lineitemDO.setL_COMMITDATE(L_COMMITDATE);
            lineitemDO.setL_RECEIPTDATE(L_RECEIPTDATE);
            lineitemDO.setL_SHIPINSTRUCT(L_SHIPINSTRUCT);
            lineitemDO.setL_SHIPMODE(L_SHIPMODE);
            lineitemDO.setL_COMMENT(L_COMMENT);

            lineitemService.updateLineitem(lineitemDO);



            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");



            //转发回首页
            response.sendRedirect(request.getContextPath() + "/LineitemServlet?type=toLineitemManager&pageNow=" + pageNow + "&keyword=" + keyword);
        }
        else if (type.equals("delete")){
            int L_ORDERKEY = Integer.parseInt(request.getParameter("L_ORDERKEY"));
            int L_LINENUMBER = Integer.parseInt(request.getParameter("L_LINENUMBER"));
            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");


            lineitemService.deleteLineitem(L_ORDERKEY,L_LINENUMBER);

            //转发回首页
            response.sendRedirect(request.getContextPath() + "/LineitemServlet?type=toLineitemManager&pageNow=" + pageNow + "&keyword=" + keyword);

        }
        else if(type.equals("detail")){
            String L_ORDERKEY = request.getParameter("O_ORDERKEY");
            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            TableResult<LineitemDO> tableResult = lineitemService.queryLineitemL_ORDERKEY(Integer.parseInt(L_ORDERKEY));
            //放入请求域中
            request.setAttribute("TableResult", tableResult);
            request.setAttribute("pageNow", Integer.parseInt(pageNow));
            request.setAttribute("keyword", keyword);

            request.getRequestDispatcher("/WEB-INF/sources/orderToLineitem.jsp").forward(request, response);
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }
}
