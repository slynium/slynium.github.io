package com.company.servlet;

import com.company.beans.entity.AdminDO;
import com.company.service.AdminService;
import com.company.service.impl.AdminServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "LoginServlet", value = "/LoginServlet")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");
        if("trueLogin".equals(type)){
            //登录成功进入index.jsp
            String userName = request.getParameter("userName");
            String pwd = request.getParameter("pwd");
            if(userName == null || userName.trim().equals("") || pwd == null || pwd.trim().equals("")){
                //用户名、密码为空的处理
                request.setAttribute("message","用户名或密码不能为空");
                request.getRequestDispatcher("/WEB-INF/login.jsp").forward(request, response);
                return;
            }

            AdminService adminService = new AdminServiceImpl();
            AdminDO adminDO = adminService.validateLogin(userName);
            if(adminDO != null && pwd.equals(adminDO.getPwd())){
                //查询有该用户，并且密码匹配
                adminDO.setPwd(null);//放到session之前清空敏感信息
                request.getSession().setAttribute("adminDO",adminDO);
                //用重定向，防止表单重复提交
                response.sendRedirect(request.getContextPath() + "/SourcesServlet?type=toSourcesManager");
            }
            else{
                //密码不匹配跳转到login.jsp
                request.setAttribute("message","用户名或密码不正确");
                request.getRequestDispatcher("/WEB-INF/login.jsp").forward(request, response);
            }
        }
        else {
            //否则跳转到login.jsp
            request.getRequestDispatcher("/WEB-INF/login.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }
}
