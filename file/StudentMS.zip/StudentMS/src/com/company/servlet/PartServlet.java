package com.company.servlet;

import com.company.beans.entity.PartDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.service.PartService;
import com.company.service.SupplierService;
import com.company.service.impl.PartServiceImpl;
import com.company.service.impl.SupplierServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "PartServlet", value = "/PartServlet")
public class PartServlet extends HttpServlet {
    private PartService partService = new PartServiceImpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");
        if(type.equals("toPartManager")){
            QueryRequest queryRequest = new QueryRequest();

            String pageNowStr = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            //默认查询第一页
            int pageNow = 1;
            if(pageNowStr != null && !pageNowStr.trim().equals("")){
                pageNow = Integer.parseInt(pageNowStr);
            }
            queryRequest.setPageNow(pageNow);
            queryRequest.setKeyword(keyword);

            TableResult<PartDO> tableResult = partService.queryPartByPage(queryRequest);
            tableResult.setPageNow(pageNow);
            tableResult.setKeyWord(keyword == null ? "" : keyword);

            //放到request的请求域中,并在sourcesManager中使用
            request.setAttribute("tableResult", tableResult);
            request.getRequestDispatcher("/WEB-INF/sources/partManager.jsp").forward(request, response);
        }
        else if (type.equals("toPartAdd")){
            request.getRequestDispatcher("/WEB-INF/sources/partAdd.jsp").forward(request, response);
        }
        else if (type.equals("add")){
            //执行添加
            String P_PARTKEY = request.getParameter("P_PARTKEY");
            String P_NAME = request.getParameter("P_NAME");
            String P_MFGR = request.getParameter("P_MFGR");
            String P_BRAND = request.getParameter("P_BRAND");
            String P_TYPE = request.getParameter("P_TYPE");
            String P_SIZE = request.getParameter("P_SIZE");
            String P_CONTAINER = request.getParameter("P_CONTAINER");
            String P_RETAILPRICE = request.getParameter("P_RETAILPRICE");
            String P_COMMENT = request.getParameter("P_COMMENT");


            PartDO partDO = new PartDO();

            partDO.setP_PARTKEY(P_PARTKEY);
            partDO.setP_NAME(P_NAME);
            partDO.setP_MFGR(P_MFGR);
            partDO.setP_BRAND(P_BRAND);
            partDO.setP_TYPE(P_TYPE);
            partDO.setP_SIZE(P_SIZE);
            partDO.setP_CONTAINER(P_CONTAINER);
            partDO.setP_RETAILPRICE(P_RETAILPRICE);
            partDO.setP_COMMENT(P_COMMENT);

            partService.addPart(partDO);


            //转发回首页
            response.sendRedirect(request.getContextPath() + "/PartServlet?type=toPartManager");

        }
        else if(type.equals("toUpdate")){
            String P_PARTKEY = request.getParameter("P_PARTKEY");
            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            PartDO partDO =  partService.getPartByP_PARTKEY(Integer.parseInt(P_PARTKEY));
            //放入请求域中
            request.setAttribute("PartDO", partDO);
            request.setAttribute("pageNow", Integer.parseInt(pageNow));
            request.setAttribute("keyword", keyword);

            request.getRequestDispatcher("/WEB-INF/sources/partUpdate.jsp").forward(request, response);
        }
        else if (type.equals("update")){
            String P_PARTKEY = request.getParameter("P_PARTKEY");
            String P_NAME = request.getParameter("P_NAME");
            String P_MFGR = request.getParameter("P_MFGR");
            String P_BRAND = request.getParameter("P_BRAND");
            String P_TYPE = request.getParameter("P_TYPE");
            String P_SIZE = request.getParameter("P_SIZE");
            String P_CONTAINER = request.getParameter("P_CONTAINER");
            String P_RETAILPRICE = request.getParameter("P_RETAILPRICE");
            String P_COMMENT = request.getParameter("P_COMMENT");


            PartDO partDO = new PartDO();

            partDO.setP_PARTKEY(P_PARTKEY);
            partDO.setP_NAME(P_NAME);
            partDO.setP_MFGR(P_MFGR);
            partDO.setP_BRAND(P_BRAND);
            partDO.setP_TYPE(P_TYPE);
            partDO.setP_SIZE(P_SIZE);
            partDO.setP_CONTAINER(P_CONTAINER);
            partDO.setP_RETAILPRICE(P_RETAILPRICE);
            partDO.setP_COMMENT(P_COMMENT);


            partService.updatePart(partDO);



            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");



            //转发回首页
            response.sendRedirect(request.getContextPath() + "/PartServlet?type=toPartManager&pageNow=" + pageNow + "&keyword=" + keyword);
        }

        else if (type.equals("delete")){
            int P_PARTKEY = Integer.parseInt(request.getParameter("P_PARTKEY"));

            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");


            partService.deletePart(P_PARTKEY);

            //转发回首页
            response.sendRedirect(request.getContextPath() + "/PartServlet?type=toPartManager&pageNow=" + pageNow + "&keyword=" + keyword);

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }
}
