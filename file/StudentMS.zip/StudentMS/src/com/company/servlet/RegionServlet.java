package com.company.servlet;

import com.company.beans.entity.NationDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.NationRequest;
import com.company.beans.req.QueryRequest;
import com.company.beans.req.RegionRequest;
import com.company.beans.res.TableResult;
import com.company.service.NationService;
import com.company.service.RegionService;
import com.company.service.impl.NationServiceImpl;
import com.company.service.impl.RegionServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "RegionServlet", value = "/RegionServlet")
public class RegionServlet extends HttpServlet {
    private RegionService regionService = new RegionServiceImpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");
        if(type.equals("toRegionManager")){
            QueryRequest queryRequest = new QueryRequest();

            String pageNowStr = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            //默认查询第一页
            int pageNow = 1;
            if(pageNowStr != null && !pageNowStr.trim().equals("")){
                pageNow = Integer.parseInt(pageNowStr);
            }
            queryRequest.setPageNow(pageNow);
            queryRequest.setKeyword(keyword);

            TableResult<RegionDO> tableResult = regionService.queryRegionByPage(queryRequest);
            tableResult.setPageNow(pageNow);
            tableResult.setKeyWord(keyword == null ? "" : keyword);

            //放到request的请求域中,并在sourcesManager中使用
            request.setAttribute("tableResult", tableResult);
            request.getRequestDispatcher("/WEB-INF/sources/regionManager.jsp").forward(request, response);
        }
        else if (type.equals("toRegionAdd")){
            request.getRequestDispatcher("/WEB-INF/sources/regionAdd.jsp").forward(request, response);
        }
        else if (type.equals("add")){
            //执行添加
            String R_REGIONKEY = request.getParameter("R_REGIONKEY");
            String R_NAME = request.getParameter("R_NAME");
            String R_COMMENT = request.getParameter("R_COMMENT");
            String PS_SUPPLYCOST = request.getParameter("PS_SUPPLYCOST");
            String PS_COMMENT = request.getParameter("PS_COMMENT");


            RegionDO regionDO = new RegionDO();

            regionDO.setR_REGIONKEY(R_REGIONKEY);
            regionDO.setR_NAME(R_NAME);
            regionDO.setR_COMMENT(R_COMMENT);
            regionDO.setPS_SUPPLYCOST(PS_SUPPLYCOST);
            regionDO.setPS_COMMENT(PS_COMMENT);

            regionService.addRegion(regionDO);


            //转发回首页
            response.sendRedirect(request.getContextPath() + "/RegionServlet?type=toRegionManager");

        }
        else if(type.equals("toUpdate")){
            String R_REGIONKEY = request.getParameter("R_REGIONKEY");
            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            RegionDO regionDO =  regionService.getRegionByR_REGIONKEY(Integer.parseInt(R_REGIONKEY));
            //放入请求域中
            request.setAttribute("RegionDO", regionDO);
            request.setAttribute("pageNow", Integer.parseInt(pageNow));
            request.setAttribute("keyword", keyword);

            request.getRequestDispatcher("/WEB-INF/sources/regionUpdate.jsp").forward(request, response);
        }
        else if (type.equals("update")){
            String R_REGIONKEY = request.getParameter("R_REGIONKEY");
            String R_NAME = request.getParameter("R_NAME");
            String R_COMMENT = request.getParameter("R_COMMENT");
            String PS_SUPPLYCOST = request.getParameter("PS_SUPPLYCOST");
            String PS_COMMENT = request.getParameter("PS_COMMENT");


            RegionDO regionDO = new RegionDO();

            regionDO.setR_REGIONKEY(R_REGIONKEY);
            regionDO.setR_NAME(R_NAME);
            regionDO.setR_COMMENT(R_COMMENT);
            regionDO.setPS_SUPPLYCOST(PS_SUPPLYCOST);
            regionDO.setPS_COMMENT(PS_COMMENT);

            regionService.updateRegion(regionDO);



            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");



            //转发回首页
            response.sendRedirect(request.getContextPath() + "/RegionServlet?type=toRegionManager&pageNow=" + pageNow + "&keyword=" + keyword);
        }
        else if (type.equals("delete")){
            int R_REGIONKEY = Integer.parseInt(request.getParameter("R_REGIONKEY"));

            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");


            regionService.deleteRegion(R_REGIONKEY);

            //转发回首页
            response.sendRedirect(request.getContextPath() + "/RegionServlet?type=toRegionManager&pageNow=" + pageNow + "&keyword=" + keyword);

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }
}
