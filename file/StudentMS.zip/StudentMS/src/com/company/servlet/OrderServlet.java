package com.company.servlet;

import com.company.beans.entity.OrderDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.service.OrderService;
import com.company.service.RegionService;
import com.company.service.impl.OrderServiceImpl;
import com.company.service.impl.RegionServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "OrderServlet", value = "/OrderServlet")
public class OrderServlet extends HttpServlet {
    private OrderService orderService = new OrderServiceImpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");
        if(type.equals("toOrderManager")){
            QueryRequest queryRequest = new QueryRequest();

            String pageNowStr = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            //默认查询第一页
            int pageNow = 1;
            if(pageNowStr != null && !pageNowStr.trim().equals("")){
                pageNow = Integer.parseInt(pageNowStr);
            }
            queryRequest.setPageNow(pageNow);
            queryRequest.setKeyword(keyword);

            TableResult<OrderDO> tableResult = orderService.queryOrderByPage(queryRequest);
            tableResult.setPageNow(pageNow);
            tableResult.setKeyWord(keyword == null ? "" : keyword);

            //放到request的请求域中,并在sourcesManager中使用
            request.setAttribute("tableResult", tableResult);
            request.getRequestDispatcher("/WEB-INF/sources/orderManager.jsp").forward(request, response);
        }
        else if (type.equals("toOrderAdd")){
            request.getRequestDispatcher("/WEB-INF/sources/orderAdd.jsp").forward(request, response);
        }
        else if (type.equals("add")){
            //执行添加
            String O_ORDERKEY = request.getParameter("O_ORDERKEY");
            String O_CUSTKEY = request.getParameter("O_CUSTKEY");
            String O_ORDERSTATUS = request.getParameter("O_ORDERSTATUS");
            String O_TOTALPRICE = request.getParameter("O_TOTALPRICE");
            String O_ORDDERDATE = request.getParameter("O_ORDDERDATE");
            String O_ORDERPRIORITY = request.getParameter("O_ORDERPRIORITY");
            String O_CLERK = request.getParameter("O_CLERK");
            String O_SHIPPRIORITY = request.getParameter("O_SHIPPRIORITY");
            String O_COMMENT = request.getParameter("O_COMMENT");


            OrderDO orderDO = new OrderDO();

            orderDO.setO_ORDERKEY(O_ORDERKEY);
            orderDO.setO_CUSTKEY(O_CUSTKEY);
            orderDO.setO_ORDERSTATUS(O_ORDERSTATUS);
            orderDO.setO_TOTALPRICE(O_TOTALPRICE);
            orderDO.setO_ORDDERDATE(O_ORDDERDATE);
            orderDO.setO_ORDERPRIORITY(O_ORDERPRIORITY);
            orderDO.setO_CLERK(O_CLERK);
            orderDO.setO_SHIPPRIORITY(O_SHIPPRIORITY);
            orderDO.setO_COMMENT(O_COMMENT);

            orderService.addOrder(orderDO);


            //转发回首页
            response.sendRedirect(request.getContextPath() + "/OrderServlet?type=toOrderManager");

        }
        else if(type.equals("toUpdate")){
            String O_ORDERKEY = request.getParameter("O_ORDERKEY");
            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            OrderDO orderDO =  orderService.getOrderByO_ORDERKEY(Integer.parseInt(O_ORDERKEY));
            //放入请求域中
            request.setAttribute("OrderDO", orderDO);
            request.setAttribute("pageNow", Integer.parseInt(pageNow));
            request.setAttribute("keyword", keyword);

            request.getRequestDispatcher("/WEB-INF/sources/orderUpdate.jsp").forward(request, response);
        }
        else if (type.equals("update")){
            String O_ORDERKEY = request.getParameter("O_ORDERKEY");
            String O_CUSTKEY = request.getParameter("O_CUSTKEY");
            String O_ORDERSTATUS = request.getParameter("O_ORDERSTATUS");
            String O_TOTALPRICE = request.getParameter("O_TOTALPRICE");
            String O_ORDDERDATE = request.getParameter("O_ORDDERDATE");
            String O_ORDERPRIORITY = request.getParameter("O_ORDERPRIORITY");
            String O_CLERK = request.getParameter("O_CLERK");
            String O_SHIPPRIORITY = request.getParameter("O_SHIPPRIORITY");
            String O_COMMENT = request.getParameter("O_COMMENT");


            OrderDO orderDO = new OrderDO();

            orderDO.setO_ORDERKEY(O_ORDERKEY);
            orderDO.setO_CUSTKEY(O_CUSTKEY);
            orderDO.setO_ORDERSTATUS(O_ORDERSTATUS);
            orderDO.setO_TOTALPRICE(O_TOTALPRICE);
            orderDO.setO_ORDDERDATE(O_ORDDERDATE);
            orderDO.setO_ORDERPRIORITY(O_ORDERPRIORITY);
            orderDO.setO_CLERK(O_CLERK);
            orderDO.setO_SHIPPRIORITY(O_SHIPPRIORITY);
            orderDO.setO_COMMENT(O_COMMENT);

            orderService.updateOrder(orderDO);



            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");



            //转发回首页
            response.sendRedirect(request.getContextPath() + "/OrderServlet?type=toOrderManager&pageNow=" + pageNow + "&keyword=" + keyword);
        }
        else if (type.equals("delete")){
            int O_ORDERKEY = Integer.parseInt(request.getParameter("O_ORDERKEY"));

            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");


            orderService.deleteOrder(O_ORDERKEY);

            //转发回首页
            response.sendRedirect(request.getContextPath() + "/OrderServlet?type=toOrderManager&pageNow=" + pageNow + "&keyword=" + keyword);

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }
}
