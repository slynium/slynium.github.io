package com.company.servlet;

import com.company.beans.entity.AdminDO;
import com.company.beans.entity.CustomerDO;
import com.company.beans.entity.NationDO;
import com.company.beans.req.CustomerRequest;
import com.company.beans.req.NationRequest;
import com.company.beans.res.TableResult;
import com.company.service.AdminService;
import com.company.service.CustomerService;
import com.company.service.NationService;
import com.company.service.impl.AdminServiceImpl;
import com.company.service.impl.CustomerServiceImpl;
import com.company.service.impl.NationServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "NationServlet", value = "/NationServlet")
public class NationServlet extends HttpServlet {
    private NationService nationService = new NationServiceImpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");
        if(type.equals("toNationManager")){
            NationRequest nationRequest = new NationRequest();

            String pageNowStr = request.getParameter("pageNow");
            String nationName = request.getParameter("keyword");
            //默认查询第一页
            int pageNow = 1;
            if(pageNowStr != null && !pageNowStr.trim().equals("")){
                pageNow = Integer.parseInt(pageNowStr);
            }
            nationRequest.setPageNow(pageNow);
            nationRequest.setNationName(nationName);

            TableResult<NationDO> tableResult = nationService.queryNationByPage(nationRequest);
            tableResult.setPageNow(pageNow);
            tableResult.setKeyWord(nationName == null ? "" : nationName);

            //放到request的请求域中,并在sourcesManager中使用
            request.setAttribute("tableResult", tableResult);
            request.getRequestDispatcher("/WEB-INF/sources/nationManager.jsp").forward(request, response);
        }
        else if (type.equals("toNationAdd")){
            request.getRequestDispatcher("/WEB-INF/sources/nationAdd.jsp").forward(request, response);
        }
        else if (type.equals("add")){
            //执行添加
            String N_NATIONKEY = request.getParameter("N_NATIONKEY");
            String N_NAME = request.getParameter("N_NAME");
            String N_REGIONKEY = request.getParameter("N_REGIONKEY");
            String N_COMMENT = request.getParameter("N_COMMENT");



            NationDO nationDO = new NationDO();

            nationDO.setN_NATIONKEY(N_NATIONKEY);
            nationDO.setN_NAME(N_NAME);
            nationDO.setN_REGIONKEY(N_REGIONKEY);
            nationDO.setN_COMMENT(N_COMMENT);

            nationService.addNation(nationDO);


            //转发回首页
            response.sendRedirect(request.getContextPath() + "/NationServlet?type=toNationManager");

        }
        else if(type.equals("toUpdate")){
            String N_NATIONKEY = request.getParameter("N_NATIONKEY");
            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");
            NationDO nationDO =  nationService.getNationByN_NATIONKEY(Integer.parseInt(N_NATIONKEY));
            //放入请求域中
            request.setAttribute("NationDO", nationDO);
            request.setAttribute("pageNow", Integer.parseInt(pageNow));
            request.setAttribute("keyword", keyword);

            request.getRequestDispatcher("/WEB-INF/sources/nationUpdate.jsp").forward(request, response);
        }
        else if (type.equals("update")){

            String N_NATIONKEY = request.getParameter("N_NATIONKEY");
            String N_NAME = request.getParameter("N_NAME");
            String N_REGIONKEY = request.getParameter("N_REGIONKEY");
            String N_COMMENT = request.getParameter("N_COMMENT");


            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");


            NationDO nationDO = new NationDO();

            nationDO.setN_NATIONKEY(N_NATIONKEY);
            nationDO.setN_NAME(N_NAME);
            nationDO.setN_REGIONKEY(N_REGIONKEY);
            nationDO.setN_COMMENT(N_COMMENT);

            nationService.updateNation(nationDO);

            //转发回首页
            response.sendRedirect(request.getContextPath() + "/NationServlet?type=toNationManager&pageNow=" + pageNow + "&keyword=" + keyword);
        }
        else if (type.equals("delete")){
            int N_NATIONKEY = Integer.parseInt(request.getParameter("N_NATIONKEY"));

            String pageNow = request.getParameter("pageNow");
            String keyword = request.getParameter("keyword");


            nationService.deleteNation(N_NATIONKEY);

            //转发回首页
            response.sendRedirect(request.getContextPath() + "/NationServlet?type=toNationManager&pageNow=" + pageNow + "&keyword=" + keyword);

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }
}
