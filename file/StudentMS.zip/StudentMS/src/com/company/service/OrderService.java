package com.company.service;

import com.company.beans.entity.OrderDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;

public interface OrderService {
    boolean addOrder(OrderDO orderDO);
    TableResult<OrderDO> queryOrderByPage(QueryRequest queryRequest);
    OrderDO getOrderByO_ORDERKEY(int O_ORDERKEY);
    boolean updateOrder(OrderDO orderDO);
    boolean deleteOrder(int O_ORDERKEY);
}
