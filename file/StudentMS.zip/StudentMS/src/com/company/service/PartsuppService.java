package com.company.service;

import com.company.beans.entity.PartsuppDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;

public interface PartsuppService {
    boolean addPartsupp(PartsuppDO partsuppDO);
    TableResult<PartsuppDO> queryPartsuppByPage(QueryRequest queryRequest);
    PartsuppDO getPartsuppByPS_PARTKEYAndPS_SUPPKEY(int PS_PARTKEY, int PS_SUPPKEY);
    boolean updatePartsupp(PartsuppDO partsuppDO);
    boolean deletePartsupp(int PS_PARTKEY, int PS_SUPPKEY);
}
