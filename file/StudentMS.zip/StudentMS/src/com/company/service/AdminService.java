package com.company.service;

import com.company.beans.entity.AdminDO;

public interface AdminService {
    AdminDO validateLogin(String userName);
}
