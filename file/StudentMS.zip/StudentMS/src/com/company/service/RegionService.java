package com.company.service;

import com.company.beans.entity.NationDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.NationRequest;
import com.company.beans.req.QueryRequest;
import com.company.beans.req.RegionRequest;
import com.company.beans.res.TableResult;

public interface RegionService {
    boolean addRegion(RegionDO RegionDO);
    TableResult<RegionDO> queryRegionByPage(QueryRequest queryRequest);
    RegionDO getRegionByR_REGIONKEY(int R_REGIONKEY);
    boolean updateRegion(RegionDO regionDO);
    boolean deleteRegion(int R_REGIONKEY);
}
