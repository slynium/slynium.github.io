package com.company.service;

import com.company.beans.entity.CustomerDO;
import com.company.beans.entity.NationDO;
import com.company.beans.req.CustomerRequest;
import com.company.beans.req.NationRequest;
import com.company.beans.res.TableResult;

public interface NationService {
    boolean addNation(NationDO nationDO);
    TableResult<NationDO> queryNationByPage(NationRequest nationRequest);
    NationDO getNationByN_NATIONKEY(int N_NATIONKEY);
    boolean updateNation(NationDO nationDO);
    boolean deleteNation(int N_NATIONKEY);
}
