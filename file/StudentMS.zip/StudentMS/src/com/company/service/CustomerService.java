package com.company.service;

import com.company.beans.entity.CustomerDO;
import com.company.beans.req.CustomerRequest;
import com.company.beans.res.TableResult;

public interface CustomerService {
    boolean addCustomer(CustomerDO customerDO);
    TableResult<CustomerDO> queryCustomerByPage(CustomerRequest customerRequest);
    CustomerDO getCustomerByC_CUSTKEY(int C_CUSTKEY);
    boolean updateCustomer(CustomerDO customerDO);
    boolean deleteCustomer(int C_CUSTKEY);
}
