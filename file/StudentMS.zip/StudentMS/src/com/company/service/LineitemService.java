package com.company.service;

import com.company.beans.entity.LineitemDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;

public interface LineitemService {
    boolean addLineitem(LineitemDO lineitemDO);
    TableResult<LineitemDO> queryLineitemByPage(QueryRequest queryRequest);
    LineitemDO getLineitemByL_ORDERKEYAndL_LINENUMBER(int L_ORDERKEY, int L_LINENUMBER);
    boolean updateLineitem(LineitemDO lineitemDO);
    boolean deleteLineitem(int L_ORDERKEY, int L_LINENUMBER);
    TableResult<LineitemDO> queryLineitemL_ORDERKEY(int L_ORDERKEY);
}
