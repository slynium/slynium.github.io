package com.company.service.impl;

import com.company.beans.entity.PartsuppDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.dao.PartsuppDao;
import com.company.dao.SupplierDao;
import com.company.dao.impl.PartsuppDaoImpl;
import com.company.dao.impl.SupplierDaoImpl;
import com.company.service.PartsuppService;
import com.company.service.SupplierService;

public class PartsuppServiceImpl implements PartsuppService {
    PartsuppDao partsuppDao = new PartsuppDaoImpl();
    @Override
    public boolean addPartsupp(PartsuppDO partsuppDO) {
        return partsuppDao.addPartsupp(partsuppDO) == 1;
    }

    @Override
    public TableResult<PartsuppDO> queryPartsuppByPage(QueryRequest queryRequest) {
        return partsuppDao.queryPartsuppByPage(queryRequest);
    }

    @Override
    public PartsuppDO getPartsuppByPS_PARTKEYAndPS_SUPPKEY(int PS_PARTKEY, int PS_SUPPKEY) {
        return partsuppDao.getPartsuppByPS_PARTKEYAndPS_SUPPKEY(PS_PARTKEY,PS_SUPPKEY);
    }

    @Override
    public boolean updatePartsupp(PartsuppDO partsuppDO) {
        return partsuppDao.updatePartsupp(partsuppDO) == 1;
    }

    @Override
    public boolean deletePartsupp(int PS_PARTKEY, int PS_SUPPKEY) {
        return partsuppDao.deletePartsupp(PS_PARTKEY,PS_SUPPKEY) == 1;
    }
}
