package com.company.service.impl;

import com.company.beans.entity.OrderDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.dao.OrderDao;
import com.company.dao.SupplierDao;
import com.company.dao.impl.OrderDaoImpl;
import com.company.dao.impl.SupplierDaoImpl;
import com.company.service.OrderService;
import com.company.service.SupplierService;

public class SupplierServiceImpl implements SupplierService {
    SupplierDao supplierDao = new SupplierDaoImpl();
    @Override
    public boolean addSupplier(SupplierDO supplierDO) {
        return supplierDao.addSupplier(supplierDO) == 1;
    }

    @Override
    public TableResult<SupplierDO> querySupplierByPage(QueryRequest queryRequest) {
        return supplierDao.querySupplierByPage(queryRequest);
    }

    @Override
    public SupplierDO getSupplierByS_SUPPKEY(int S_SUPPKEY) {
        return supplierDao.getSupplierByS_SUPPKEY(S_SUPPKEY);
    }

    @Override
    public boolean updateSupplier(SupplierDO supplierDO) {
        return supplierDao.updateSupplier(supplierDO) == 1;
    }

    @Override
    public boolean deleteSupplier(int S_SUPPKEY) {
        return supplierDao.deleteSupplier(S_SUPPKEY) == 1;
    }
}
