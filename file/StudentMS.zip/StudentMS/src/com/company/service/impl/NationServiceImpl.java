package com.company.service.impl;

import com.company.beans.entity.CustomerDO;
import com.company.beans.entity.NationDO;
import com.company.beans.req.CustomerRequest;
import com.company.beans.req.NationRequest;
import com.company.beans.res.TableResult;
import com.company.dao.CustomerDao;
import com.company.dao.NationDao;
import com.company.dao.impl.CustomerDaoImpl;
import com.company.dao.impl.NationDaoImpl;
import com.company.service.CustomerService;
import com.company.service.NationService;

public class NationServiceImpl implements NationService {
    private NationDao nationDao = new NationDaoImpl();
    @Override
    public boolean addNation(NationDO nationDO) {
        return nationDao.addNation(nationDO) == 1;
    }

    @Override
    public TableResult<NationDO> queryNationByPage(NationRequest nationRequest) {
        return nationDao.queryNationByPage(nationRequest);
    }

    @Override
    public NationDO getNationByN_NATIONKEY(int N_NATIONKEY) {
        return nationDao.getNationByN_NATIONKEY(N_NATIONKEY);
    }

    @Override
    public boolean updateNation(NationDO nationDO) {
        return nationDao.updateNation(nationDO) == 1;
    }

    @Override
    public boolean deleteNation(int N_NATIONKEY) {
        return nationDao.deleteNation(N_NATIONKEY) == 1;
    }
}
