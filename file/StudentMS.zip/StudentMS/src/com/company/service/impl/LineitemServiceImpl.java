package com.company.service.impl;

import com.company.beans.entity.LineitemDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.dao.LineitemDao;
import com.company.dao.RegionDao;
import com.company.dao.impl.LineitemDaoImpl;
import com.company.dao.impl.RegionDaoImpl;
import com.company.service.LineitemService;
import com.company.service.RegionService;

public class LineitemServiceImpl implements LineitemService {
    private LineitemDao lineitemDao = new LineitemDaoImpl();
    @Override
    public boolean addLineitem(LineitemDO lineitemDO) {
        return lineitemDao.addLineitem(lineitemDO) == 1;
    }

    @Override
    public TableResult<LineitemDO> queryLineitemByPage(QueryRequest queryRequest) {
        return lineitemDao.queryLineitemByPage(queryRequest);
    }

    @Override
    public LineitemDO getLineitemByL_ORDERKEYAndL_LINENUMBER(int L_ORDERKEY,int L_LINENUMBER) {
        return lineitemDao.getLineitemByL_ORDERKEYAndL_LINENUMBER(L_ORDERKEY, L_LINENUMBER);
    }

    @Override
    public boolean updateLineitem(LineitemDO lineitemDO) {
        return lineitemDao.updateLineitem(lineitemDO) == 1;
    }

    @Override
    public boolean deleteLineitem(int L_ORDERKEY, int L_LINENUMBER) {
        return lineitemDao.deleteLineitem(L_ORDERKEY,L_LINENUMBER) == 1;
    }

    @Override
    public TableResult<LineitemDO> queryLineitemL_ORDERKEY(int L_ORDERKEY) {
        return lineitemDao.queryLineitemL_ORDERKEY(L_ORDERKEY);
    }
}
