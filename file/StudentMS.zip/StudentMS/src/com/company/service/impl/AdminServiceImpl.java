package com.company.service.impl;

import com.company.beans.entity.AdminDO;
import com.company.dao.AdminDao;
import com.company.dao.impl.AdminDaoImpl;
import com.company.service.AdminService;

public class AdminServiceImpl implements AdminService {

    private AdminDao adminDao = new AdminDaoImpl();
    @Override
    public AdminDO validateLogin(String userName) {
        return adminDao.validateLogin(userName);
    }
}
