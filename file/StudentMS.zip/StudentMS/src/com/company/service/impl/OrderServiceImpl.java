package com.company.service.impl;

import com.company.beans.entity.OrderDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.dao.OrderDao;
import com.company.dao.impl.OrderDaoImpl;
import com.company.service.OrderService;

public class OrderServiceImpl implements OrderService {
    OrderDao orderDao = new OrderDaoImpl();
    @Override
    public boolean addOrder(OrderDO orderDO) {
        return orderDao.addOrder(orderDO) == 1;
    }

    @Override
    public TableResult<OrderDO> queryOrderByPage(QueryRequest queryRequest) {
        return orderDao.queryOrderByPage(queryRequest);
    }

    @Override
    public OrderDO getOrderByO_ORDERKEY(int O_ORDERKEY) {
        return orderDao.getOrderByO_ORDERKEY(O_ORDERKEY);
    }

    @Override
    public boolean updateOrder(OrderDO orderDO) {
        return orderDao.updateOrder(orderDO) == 1;
    }

    @Override
    public boolean deleteOrder(int O_ORDERKEY) {
        return orderDao.deleteOrder(O_ORDERKEY) == 1;
    }
}
