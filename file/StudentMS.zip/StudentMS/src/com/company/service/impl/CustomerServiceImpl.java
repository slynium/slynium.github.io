package com.company.service.impl;

import com.company.beans.entity.CustomerDO;
import com.company.beans.req.CustomerRequest;
import com.company.beans.res.TableResult;
import com.company.dao.CustomerDao;
import com.company.dao.impl.CustomerDaoImpl;
import com.company.service.CustomerService;

public class CustomerServiceImpl implements CustomerService {
    private CustomerDao customerDao = new CustomerDaoImpl();
    @Override
    public boolean addCustomer(CustomerDO customerDO) {
        return customerDao.addCustomer(customerDO) == 1;
    }

    @Override
    public TableResult<CustomerDO> queryCustomerByPage(CustomerRequest customerRequest) {
        return customerDao.queryCustomerByPage(customerRequest);
    }

    @Override
    public CustomerDO getCustomerByC_CUSTKEY(int C_CUSTKEY) {
        return customerDao.getCustomerByC_CUSTKEY(C_CUSTKEY);
    }

    @Override
    public boolean updateCustomer(CustomerDO customerDO) {
        return customerDao.updateCustomer(customerDO) == 1;
    }

    @Override
    public boolean deleteCustomer(int C_CUSTKEY) {
        return customerDao.deleteCustomer(C_CUSTKEY) == 1;
    }
}
