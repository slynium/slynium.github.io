package com.company.service.impl;

import com.company.beans.entity.PartDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.dao.PartDao;
import com.company.dao.SupplierDao;
import com.company.dao.impl.PartDaoImpl;
import com.company.dao.impl.SupplierDaoImpl;
import com.company.service.PartService;
import com.company.service.SupplierService;

public class PartServiceImpl implements PartService {
    PartDao partDao = new PartDaoImpl();
    @Override
    public boolean addPart(PartDO partDO) {
        return partDao.addPart(partDO) == 1;
    }

    @Override
    public TableResult<PartDO> queryPartByPage(QueryRequest queryRequest) {
        return partDao.queryPartByPage(queryRequest);
    }

    @Override
    public PartDO getPartByP_PARTKEY(int P_PARTKEY) {
        return partDao.getPartByP_PARTKEY(P_PARTKEY);
    }

    @Override
    public boolean updatePart(PartDO partDO) {
        return partDao.updatePart(partDO) == 1;
    }

    @Override
    public boolean deletePart(int P_PARTKEY) {
        return partDao.deletePart(P_PARTKEY) == 1;
    }
}
