package com.company.service.impl;

import com.company.beans.entity.NationDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.NationRequest;
import com.company.beans.req.QueryRequest;
import com.company.beans.req.RegionRequest;
import com.company.beans.res.TableResult;
import com.company.dao.NationDao;
import com.company.dao.RegionDao;
import com.company.dao.impl.NationDaoImpl;
import com.company.dao.impl.RegionDaoImpl;
import com.company.service.NationService;
import com.company.service.RegionService;

public class RegionServiceImpl implements RegionService {
    private RegionDao regionDao = new RegionDaoImpl();
    @Override
    public boolean addRegion(RegionDO regionDO) {
        return regionDao.addRegion(regionDO) == 1;
    }

    @Override
    public TableResult<RegionDO> queryRegionByPage(QueryRequest queryRequest) {
        return regionDao.queryRegionByPage(queryRequest);
    }

    @Override
    public RegionDO getRegionByR_REGIONKEY(int R_REGIONKEY) {
        return regionDao.getRegionByR_REGIONKEY(R_REGIONKEY);
    }

    @Override
    public boolean updateRegion(RegionDO regionDO) {
        return regionDao.updateRegion(regionDO) == 1;
    }

    @Override
    public boolean deleteRegion(int R_REGIONKEY) {
        return regionDao.deleteRegion(R_REGIONKEY) == 1;
    }
}
