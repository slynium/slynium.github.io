package com.company.service;

import com.company.beans.entity.OrderDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;

public interface SupplierService {
    boolean addSupplier(SupplierDO supplierDO);
    TableResult<SupplierDO> querySupplierByPage(QueryRequest queryRequest);
    SupplierDO getSupplierByS_SUPPKEY(int S_SUPPKEY);
    boolean updateSupplier(SupplierDO supplierDO);
    boolean deleteSupplier(int S_SUPPKEY);
}
