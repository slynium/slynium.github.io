package com.company.service;

import com.company.beans.entity.PartDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;

public interface PartService {
    boolean addPart(PartDO partDO);
    TableResult<PartDO> queryPartByPage(QueryRequest queryRequest);
    PartDO getPartByP_PARTKEY(int P_PARTKEY);
    boolean updatePart(PartDO partDO);
    boolean deletePart(int P_PARTKEY);
}
