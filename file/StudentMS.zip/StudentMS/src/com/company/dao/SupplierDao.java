package com.company.dao;

import com.company.beans.entity.OrderDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;

public interface SupplierDao {
    int addSupplier(SupplierDO supplierDO);

    //分页查询国籍
    TableResult<SupplierDO> querySupplierByPage(QueryRequest queryRequest);

    SupplierDO getSupplierByS_SUPPKEY(int S_SUPPKEY);

    int updateSupplier(SupplierDO supplierDO);
    int deleteSupplier(int S_SUPPKEY);
}
