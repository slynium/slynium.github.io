package com.company.dao;

import com.company.beans.entity.CustomerDO;
import com.company.beans.req.CustomerRequest;
import com.company.beans.res.TableResult;

public interface CustomerDao {
    int addCustomer(CustomerDO customerDO);

    //分页查询学生
    TableResult<CustomerDO> queryCustomerByPage(CustomerRequest customerRequest);

    CustomerDO getCustomerByC_CUSTKEY(int C_CUSTKEY);

    int updateCustomer(CustomerDO customerDO);
    int deleteCustomer(int C_CUSTKEY);
}
