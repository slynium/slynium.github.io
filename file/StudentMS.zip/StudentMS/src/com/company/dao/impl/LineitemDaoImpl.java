package com.company.dao.impl;

import com.company.beans.entity.LineitemDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.dao.LineitemDao;
import com.company.dao.RegionDao;
import com.company.util.DBUtil;
import com.company.util.StringUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LineitemDaoImpl implements LineitemDao {



    @Override
    public int addLineitem(LineitemDO lineitemDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("insert into lineitem(L_ORDERKEY,L_PARTKEY, L_SUPPKEY,L_LINENUMBER,L_QUANTITY,L_EXTENDEDPRICE," +
                "L_DISCOUNT,L_TAX,L_RETURNFLAG,L_LINESTATUS,L_SHIPDATE,L_COMMITDATE,L_RECEIPTDATE,L_SHIPINSTRUCT," +
                "L_SHIPMODE,L_COMMENT) ");
        sb.append("value(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,lineitemDO.getL_ORDERKEY());
            ps.setObject(2,lineitemDO.getL_PARTKEY());
            ps.setObject(3,lineitemDO.getL_SUPPKEY());
            ps.setObject(4,lineitemDO.getL_LINENUMBER());
            ps.setObject(5,lineitemDO.getL_QUANTITY());
            ps.setObject(6,lineitemDO.getL_EXTENDEDPRICE());
            ps.setObject(7,lineitemDO.getL_DISCOUNT());
            ps.setObject(8,lineitemDO.getL_TAX());
            ps.setObject(9,lineitemDO.getL_RETURNFLAG());
            ps.setObject(10,lineitemDO.getL_LINESTATUS());
            ps.setObject(11,lineitemDO.getL_SHIPDATE());
            ps.setObject(12,lineitemDO.getL_COMMITDATE());
            ps.setObject(13,lineitemDO.getL_RECEIPTDATE());
            ps.setObject(14,lineitemDO.getL_SHIPINSTRUCT());
            ps.setObject(15,lineitemDO.getL_SHIPMODE());
            ps.setObject(16,lineitemDO.getL_COMMENT());
            //打印最终执行的SQL语句
            System.out.println("addLineitem执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变函数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public TableResult<LineitemDO> queryLineitemByPage(QueryRequest queryRequest) {
        TableResult<LineitemDO> tableResult = new TableResult<>();
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;

        /**页面查询*/
        StringBuilder sb = new StringBuilder();
        sb.append("select L_ORDERKEY,L_PARTKEY, L_SUPPKEY,L_LINENUMBER,L_QUANTITY," +
                "L_EXTENDEDPRICE,L_DISCOUNT,L_TAX,L_RETURNFLAG,L_LINESTATUS,L_SHIPDATE," +
                "L_COMMITDATE,L_RECEIPTDATE,L_SHIPINSTRUCT,L_SHIPMODE,L_COMMENT ");
        sb.append("from lineitem where L_ORDERKEY like ? ");
        sb.append("order by L_ORDERKEY asc ");
        sb.append("limit " + queryRequest.getStart() + ", " + queryRequest.getPageSize());
        try {
            ps = conn.prepareStatement(sb.toString());//先预编译，再传参数
            if(StringUtil.isNotBlank(queryRequest.getKeyword())){
                ps.setObject(1,"%" + queryRequest.getKeyword() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryLineitemByPage执行的SQL1:" + ps.toString());

            rs = ps.executeQuery();
            List<LineitemDO> list = new ArrayList<>();
            while (rs.next()){
                LineitemDO lineitemDO= buildLineitem(rs);
                list.add(lineitemDO);
            }
            tableResult.setData(list);

            /**查询总条数*/
            sb.setLength(0);
            sb.append("select count(*) from lineitem where L_ORDERKEY like ?");
            ps = conn.prepareStatement(sb.toString());//预编译
            if(StringUtil.isNotBlank(queryRequest.getKeyword())){
                ps.setObject(1,"%" + queryRequest.getKeyword() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryLineitemByPage执行的SQL2:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()) {
                tableResult.setTotalCount(rs.getInt(1));
            }
            return tableResult;

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public LineitemDO getLineitemByL_ORDERKEYAndL_LINENUMBER(int L_ORDERKEY, int L_LINENUMBER) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        StringBuilder sb = new StringBuilder();
        sb.append("select L_ORDERKEY,L_PARTKEY, L_SUPPKEY,L_LINENUMBER,L_QUANTITY," +
                "L_EXTENDEDPRICE,L_DISCOUNT,L_TAX,L_RETURNFLAG,L_LINESTATUS,L_SHIPDATE," +
                "L_COMMITDATE,L_RECEIPTDATE,L_SHIPINSTRUCT,L_SHIPMODE,L_COMMENT " +
                " from lineitem where L_ORDERKEY = ? and L_LINENUMBER = ?");
        try {
            ps = conn.prepareStatement(sb.toString());//预编译
            ps.setObject(1, L_ORDERKEY);
            ps.setObject(2, L_LINENUMBER);
            //打印最终执行的SQL语句
            System.out.println("getLineitemByL_ORDERKEY执行的SQL:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()){
                return buildLineitem(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public int updateLineitem(LineitemDO lineitemDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("update lineitem set L_PARTKEY = ?, L_SUPPKEY = ?,L_QUANTITY = ?," +
                "L_EXTENDEDPRICE = ?,L_DISCOUNT = ?,L_TAX = ?,L_RETURNFLAG = ?,L_LINESTATUS = ?," +
                "L_SHIPDATE = ?,L_COMMITDATE = ?,L_RECEIPTDATE = ?,L_SHIPINSTRUCT = ?,L_SHIPMODE = ?," +
                "L_COMMENT = ? where L_ORDERKEY = ? and L_LINENUMBER = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,lineitemDO.getL_PARTKEY());
            ps.setObject(2,lineitemDO.getL_SUPPKEY());
            ps.setObject(3,lineitemDO.getL_QUANTITY());
            ps.setObject(4,lineitemDO.getL_EXTENDEDPRICE());
            ps.setObject(5,lineitemDO.getL_DISCOUNT());
            ps.setObject(6,lineitemDO.getL_TAX());
            ps.setObject(7,lineitemDO.getL_RETURNFLAG());
            ps.setObject(8,lineitemDO.getL_LINESTATUS());
            ps.setObject(9,lineitemDO.getL_SHIPDATE());
            ps.setObject(10,lineitemDO.getL_COMMITDATE());
            ps.setObject(11,lineitemDO.getL_RECEIPTDATE());
            ps.setObject(12,lineitemDO.getL_SHIPINSTRUCT());
            ps.setObject(13,lineitemDO.getL_SHIPMODE());
            ps.setObject(14,lineitemDO.getL_COMMENT());
            ps.setObject(15,lineitemDO.getL_ORDERKEY());
            ps.setObject(16,lineitemDO.getL_LINENUMBER());
            //打印最终执行的SQL语句
            System.out.println("updateLineitem执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public int deleteLineitem(int L_ORDERKEY, int L_LINENUMBER) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("delete from lineitem where L_ORDERKEY = ? and L_LINENUMBER = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,L_ORDERKEY);
            ps.setObject(2,L_LINENUMBER);
            //打印最终执行的SQL语句
            System.out.println("deleteLineitem执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public TableResult<LineitemDO> queryLineitemL_ORDERKEY(int L_ORDERKEY) {
        TableResult<LineitemDO> tableResult = new TableResult<>();
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;

        /**页面查询*/
        StringBuilder sb = new StringBuilder();
        sb.append("select L_ORDERKEY,L_PARTKEY, L_SUPPKEY,L_LINENUMBER,L_QUANTITY," +
                "L_EXTENDEDPRICE,L_DISCOUNT,L_TAX,L_RETURNFLAG,L_LINESTATUS,L_SHIPDATE," +
                "L_COMMITDATE,L_RECEIPTDATE,L_SHIPINSTRUCT,L_SHIPMODE,L_COMMENT ");
        sb.append("from lineitem where L_ORDERKEY = ? ");
        sb.append("order by L_LINENUMBER asc ");
        try {
            ps = conn.prepareStatement(sb.toString());//先预编译，再传参数
            ps.setObject(1,L_ORDERKEY);

            //打印最终执行的SQL语句
            System.out.println("queryLineitemL_ORDERKEY执行的SQL1:" + ps.toString());

            rs = ps.executeQuery();
            List<LineitemDO> list = new ArrayList<>();
            while (rs.next()){
                LineitemDO lineitemDO= buildLineitem(rs);
                list.add(lineitemDO);
            }
            tableResult.setData(list);


            return tableResult;

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }


    //内部使用的函数
    private LineitemDO buildLineitem(ResultSet rs) throws SQLException {
        LineitemDO lineitemDO = new LineitemDO();
        lineitemDO.setL_ORDERKEY(rs.getString("L_ORDERKEY"));
        lineitemDO.setL_PARTKEY(rs.getString("L_PARTKEY"));
        lineitemDO.setL_SUPPKEY(rs.getString("L_SUPPKEY"));
        lineitemDO.setL_LINENUMBER(rs.getString("L_LINENUMBER"));
        lineitemDO.setL_QUANTITY(rs.getString("L_QUANTITY"));
        lineitemDO.setL_EXTENDEDPRICE(rs.getString("L_EXTENDEDPRICE"));
        lineitemDO.setL_DISCOUNT(rs.getString("L_DISCOUNT"));
        lineitemDO.setL_TAX(rs.getString("L_TAX"));
        lineitemDO.setL_RETURNFLAG(rs.getString("L_RETURNFLAG"));
        lineitemDO.setL_LINESTATUS(rs.getString("L_LINESTATUS"));
        lineitemDO.setL_SHIPDATE(rs.getString("L_SHIPDATE"));
        lineitemDO.setL_COMMITDATE(rs.getString("L_COMMITDATE"));
        lineitemDO.setL_RECEIPTDATE(rs.getString("L_RECEIPTDATE"));
        lineitemDO.setL_SHIPINSTRUCT(rs.getString("L_SHIPINSTRUCT"));
        lineitemDO.setL_SHIPMODE(rs.getString("L_SHIPMODE"));
        lineitemDO.setL_COMMENT(rs.getString("L_COMMENT"));

        return lineitemDO;
    }

}
