package com.company.dao.impl;

import com.company.beans.entity.RegionDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.dao.RegionDao;
import com.company.util.DBUtil;
import com.company.util.StringUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RegionDaoImpl implements RegionDao {
    @Override
    public int addRegion(RegionDO regionDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("insert into region(R_REGIONKEY,R_NAME, R_COMMENT,PS_SUPPLYCOST,PS_COMMENT) ");
        sb.append("value(?,?,?,?,?)");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,regionDO.getR_REGIONKEY());
            ps.setObject(2,regionDO.getR_NAME());
            ps.setObject(3,regionDO.getR_COMMENT());
            ps.setObject(4,regionDO.getPS_SUPPLYCOST());
            ps.setObject(5,regionDO.getPS_COMMENT());
            //打印最终执行的SQL语句
            System.out.println("addRegion执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变函数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public TableResult<RegionDO> queryRegionByPage(QueryRequest queryRequest) {
        TableResult<RegionDO> tableResult = new TableResult<>();
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;

        /**页面查询*/
        StringBuilder sb = new StringBuilder();
        sb.append("select R_REGIONKEY,R_NAME, R_COMMENT,PS_SUPPLYCOST,PS_COMMENT ");
        sb.append("from region where R_NAME like ? ");
        sb.append("order by R_REGIONKEY asc ");
        sb.append("limit " + queryRequest.getStart() + ", " + queryRequest.getPageSize());
        try {
            ps = conn.prepareStatement(sb.toString());//先预编译，再传参数
            if(StringUtil.isNotBlank(queryRequest.getKeyword())){
                ps.setObject(1,"%" + queryRequest.getKeyword() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryRegionByPage执行的SQL1:" + ps.toString());

            rs = ps.executeQuery();
            List<RegionDO> list = new ArrayList<>();
            while (rs.next()){
                RegionDO regionDO= buildRegion(rs);
                list.add(regionDO);
            }
            tableResult.setData(list);

            /**查询总条数*/
            sb.setLength(0);
            sb.append("select count(*) from region where R_NAME like ?");
            ps = conn.prepareStatement(sb.toString());//预编译
            if(StringUtil.isNotBlank(queryRequest.getKeyword())){
                ps.setObject(1,"%" + queryRequest.getKeyword() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryRegionByPage执行的SQL2:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()) {
                tableResult.setTotalCount(rs.getInt(1));
            }
            return tableResult;

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public RegionDO getRegionByR_REGIONKEY(int R_REGIONKEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        StringBuilder sb = new StringBuilder();
        sb.append("select R_REGIONKEY,R_NAME, R_COMMENT,PS_SUPPLYCOST,PS_COMMENT" +
                " from region where R_REGIONKEY = ?");
        try {
            ps = conn.prepareStatement(sb.toString());//预编译
            ps.setObject(1, R_REGIONKEY);
            //打印最终执行的SQL语句
            System.out.println("getRegionByR_REGIONKEY执行的SQL:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()){
                return buildRegion(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public int updateRegion(RegionDO regionDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("update region set R_NAME = ?,R_COMMENT = ?,PS_SUPPLYCOST = ?,PS_COMMENT = ?" +
                " where R_REGIONKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,regionDO.getR_NAME());
            ps.setObject(2,regionDO.getR_COMMENT());
            ps.setObject(3,regionDO.getPS_SUPPLYCOST());
            ps.setObject(4,regionDO.getPS_COMMENT());
            ps.setObject(5,regionDO.getR_REGIONKEY());
            //打印最终执行的SQL语句
            System.out.println("updateRegion执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public int deleteRegion(int R_REGIONKEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("delete from region where R_REGIONKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,R_REGIONKEY);
            //打印最终执行的SQL语句
            System.out.println("deleteRegion执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    //内部使用的函数
    private RegionDO buildRegion(ResultSet rs) throws SQLException {
        RegionDO regionDO = new RegionDO();
        regionDO.setR_REGIONKEY(rs.getString("R_REGIONKEY"));
        regionDO.setR_NAME(rs.getString("R_NAME"));
        regionDO.setR_COMMENT(rs.getString("R_COMMENT"));
        regionDO.setPS_SUPPLYCOST(rs.getString("PS_SUPPLYCOST"));
        regionDO.setPS_COMMENT(rs.getString("PS_COMMENT"));

        return regionDO;
    }
}
