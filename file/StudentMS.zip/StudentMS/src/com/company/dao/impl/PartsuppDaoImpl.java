package com.company.dao.impl;

import com.company.beans.entity.PartsuppDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.dao.PartsuppDao;
import com.company.util.DBUtil;
import com.company.util.StringUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PartsuppDaoImpl implements PartsuppDao {
    @Override
    public int addPartsupp(PartsuppDO partsuppDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("insert into partsupp(PS_PARTKEY, PS_SUPPKEY, PS_AVAILQTY,PS_SUPPLYCOST,PS_COMMENT) ");
        sb.append("value(?,?,?,?,?)");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,partsuppDO.getPS_PARTKEY());
            ps.setObject(2,partsuppDO.getPS_SUPPKEY());
            ps.setObject(3,partsuppDO.getPS_AVAILQTY());
            ps.setObject(4,partsuppDO.getPS_SUPPLYCOST());
            ps.setObject(5,partsuppDO.getPS_COMMENT());
            //打印最终执行的SQL语句
            System.out.println("addPartsupp执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变函数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public TableResult<PartsuppDO> queryPartsuppByPage(QueryRequest queryRequest) {
        TableResult<PartsuppDO> tableResult = new TableResult<>();
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;

        /**页面查询*/
        StringBuilder sb = new StringBuilder();
        sb.append("select PS_PARTKEY, PS_SUPPKEY, PS_AVAILQTY,PS_SUPPLYCOST,PS_COMMENT");
        sb.append(" from partsupp where PS_PARTKEY like ? ");
        sb.append("order by PS_PARTKEY asc ");
        sb.append("limit " + queryRequest.getStart() + ", " + queryRequest.getPageSize());
        try {
            ps = conn.prepareStatement(sb.toString());//先预编译，再传参数
            if(StringUtil.isNotBlank(queryRequest.getKeyword())){
                ps.setObject(1,"%" + queryRequest.getKeyword() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryPartsuppByPage执行的SQL1:" + ps.toString());

            rs = ps.executeQuery();
            List<PartsuppDO> list = new ArrayList<>();
            while (rs.next()){
                PartsuppDO partsuppDO= buildPartsupp(rs);
                list.add(partsuppDO);
            }
            tableResult.setData(list);

            /**查询总条数*/
            sb.setLength(0);
            sb.append("select count(*) from partsupp where PS_PARTKEY like ?");
            ps = conn.prepareStatement(sb.toString());//预编译
            if(StringUtil.isNotBlank(queryRequest.getKeyword())){
                ps.setObject(1,"%" + queryRequest.getKeyword() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryPartsuppByPage执行的SQL2:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()) {
                tableResult.setTotalCount(rs.getInt(1));
            }
            return tableResult;

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public PartsuppDO getPartsuppByPS_PARTKEYAndPS_SUPPKEY(int PS_PARTKEY, int PS_SUPPKEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        StringBuilder sb = new StringBuilder();
        sb.append("select PS_PARTKEY, PS_SUPPKEY, PS_AVAILQTY,PS_SUPPLYCOST,PS_COMMENT" +
                " from partsupp where PS_PARTKEY = ? and PS_SUPPKEY = ?");
        try {
            ps = conn.prepareStatement(sb.toString());//预编译
            ps.setObject(1, PS_PARTKEY);
            ps.setObject(2,PS_SUPPKEY);
            //打印最终执行的SQL语句
            System.out.println("getPartsuppByPS_PARTKEYAndPS_SUPPKEY执行的SQL:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()){
                return buildPartsupp(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public int updatePartsupp(PartsuppDO partsuppDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("update partsupp set PS_AVAILQTY = ?, PS_SUPPLYCOST = ?,PS_COMMENT = ? " +
                " where PS_PARTKEY = ? and PS_SUPPKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,partsuppDO.getPS_AVAILQTY());
            ps.setObject(2,partsuppDO.getPS_SUPPLYCOST());
            ps.setObject(3,partsuppDO.getPS_COMMENT());
            ps.setObject(4,partsuppDO.getPS_PARTKEY());
            ps.setObject(5,partsuppDO.getPS_SUPPKEY());
            //打印最终执行的SQL语句
            System.out.println("updatePartsupp执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public int deletePartsupp(int PS_PARTKEY, int PS_SUPPKEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("delete from partsupp where PS_PARTKEY = ? and PS_SUPPKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,PS_PARTKEY);
            ps.setObject(2,PS_SUPPKEY);
            //打印最终执行的SQL语句
            System.out.println("deletePartsupp执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    //内部使用的函数
    private PartsuppDO buildPartsupp(ResultSet rs) throws SQLException {
        PartsuppDO partsuppDO = new PartsuppDO();

        partsuppDO.setPS_PARTKEY(rs.getString("PS_PARTKEY"));
        partsuppDO.setPS_SUPPKEY(rs.getString("PS_SUPPKEY"));
        partsuppDO.setPS_AVAILQTY(rs.getString("PS_AVAILQTY"));
        partsuppDO.setPS_SUPPLYCOST(rs.getString("PS_SUPPLYCOST"));
        partsuppDO.setPS_COMMENT(rs.getString("PS_COMMENT"));

        return partsuppDO;
    }

}
