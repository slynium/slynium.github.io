package com.company.dao.impl;

import com.company.beans.entity.CustomerDO;
import com.company.beans.entity.NationDO;
import com.company.beans.req.CustomerRequest;
import com.company.beans.req.NationRequest;
import com.company.beans.res.TableResult;
import com.company.dao.CustomerDao;
import com.company.dao.NationDao;
import com.company.util.DBUtil;
import com.company.util.StringUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NationDaoImpl implements NationDao {

    @Override
    public int addNation(NationDO nationDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("insert into nation(N_NATIONKEY,N_NAME,N_REGIONKEY,N_COMMENT) ");
        sb.append("value(?,?,?,?)");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,nationDO.getN_NATIONKEY());
            ps.setObject(2,nationDO.getN_NAME());
            ps.setObject(3,nationDO.getN_REGIONKEY());
            ps.setObject(4,nationDO.getN_COMMENT());
            //打印最终执行的SQL语句
            System.out.println("addNation执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变函数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public TableResult<NationDO> queryNationByPage(NationRequest nationRequest) {
        TableResult<NationDO> tableResult = new TableResult<>();
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;

        /**页面查询*/
        StringBuilder sb = new StringBuilder();
        sb.append("select N_NATIONKEY,N_NAME,N_REGIONKEY,N_COMMENT ");
        sb.append("from nation where N_NAME like ? ");
        sb.append("order by N_NATIONKEY asc ");
        sb.append("limit " + nationRequest.getStart() + ", " + nationRequest.getPageSize());
        try {
            ps = conn.prepareStatement(sb.toString());//先预编译，再传参数
            if(StringUtil.isNotBlank(nationRequest.getNationName())){
                ps.setObject(1,"%" + nationRequest.getNationName() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryNationByPage执行的SQL1:" + ps.toString());

            rs = ps.executeQuery();
            List<NationDO> list = new ArrayList<>();
            while (rs.next()){
                NationDO nationDO= buildNation(rs);
                list.add(nationDO);
            }
            tableResult.setData(list);

            /**查询总条数*/
            sb.setLength(0);
            sb.append("select count(*) from nation where N_NAME like ?");
            ps = conn.prepareStatement(sb.toString());//预编译
            if(StringUtil.isNotBlank(nationRequest.getNationName())){
                ps.setObject(1,"%" + nationRequest.getNationName() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryNationByPage执行的SQL2:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()) {
                tableResult.setTotalCount(rs.getInt(1));
            }
            return tableResult;

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public NationDO getNationByN_NATIONKEY(int N_NATIONKEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        StringBuilder sb = new StringBuilder();
        sb.append("select N_NATIONKEY, N_NAME, N_REGIONKEY,N_COMMENT" +
                " from nation where N_NATIONKEY = ?");
        try {
            ps = conn.prepareStatement(sb.toString());//预编译
            ps.setObject(1, N_NATIONKEY);
            //打印最终执行的SQL语句
            System.out.println("getNatoinByN_NATIONKEY执行的SQL:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()){
                return buildNation(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public int updateNation(NationDO nationDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("update nation set N_NAME = ?,N_REGIONKEY = ?,N_COMMENT = ?" +
                " where N_NATIONKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,nationDO.getN_NAME());
            ps.setObject(2,nationDO.getN_REGIONKEY());
            ps.setObject(3,nationDO.getN_COMMENT());
            ps.setObject(4,nationDO.getN_NATIONKEY());
            //打印最终执行的SQL语句
            System.out.println("updateNation执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public int deleteNation(int N_NATIONEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("delete from nation where N_NATIONKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,N_NATIONEY);
            //打印最终执行的SQL语句
            System.out.println("deleteNation执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }


    //内部使用的函数
    private NationDO buildNation(ResultSet rs) throws SQLException {
        NationDO nationDO = new NationDO();
        nationDO.setN_NATIONKEY(rs.getString("N_NATIONKEY"));
        nationDO.setN_NAME(rs.getString("N_NAME"));
        nationDO.setN_REGIONKEY(rs.getString("N_REGIONKEY"));
        nationDO.setN_COMMENT(rs.getString("N_COMMENT"));

        return nationDO;
    }
}
