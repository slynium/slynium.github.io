package com.company.dao.impl;

import com.company.beans.entity.PartDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.dao.PartDao;
import com.company.util.DBUtil;
import com.company.util.StringUtil;

import javax.servlet.http.Part;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PartDaoImpl implements PartDao {
    @Override
    public int addPart(PartDO partDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("insert into part(P_PARTKEY, P_NAME, P_MFGR,P_BRAND,"+
                "P_TYPE,P_SIZE,P_CONTAINER,P_RETAILPRICE,P_COMMENT) ");
        sb.append("value(?,?,?,?,?,?,?,?,?)");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,partDO.getP_PARTKEY());
            ps.setObject(2,partDO.getP_NAME());
            ps.setObject(3,partDO.getP_MFGR());
            ps.setObject(4,partDO.getP_BRAND());
            ps.setObject(5,partDO.getP_TYPE());
            ps.setObject(6,partDO.getP_SIZE());
            ps.setObject(7,partDO.getP_CONTAINER());
            ps.setObject(8,partDO.getP_RETAILPRICE());
            ps.setObject(9,partDO.getP_COMMENT());

            //打印最终执行的SQL语句
            System.out.println("addPart执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变函数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public TableResult<PartDO> queryPartByPage(QueryRequest queryRequest) {
        TableResult<PartDO> tableResult = new TableResult<>();
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;

        /**页面查询*/
        StringBuilder sb = new StringBuilder();
        sb.append("select P_PARTKEY, P_NAME, P_MFGR,P_BRAND,"+
                "P_TYPE,P_SIZE,P_CONTAINER,P_RETAILPRICE,P_COMMENT ");
        sb.append("from part where P_NAME like ? ");
        sb.append("order by P_PARTKEY asc ");
        sb.append("limit " + queryRequest.getStart() + ", " + queryRequest.getPageSize());
        try {
            ps = conn.prepareStatement(sb.toString());//先预编译，再传参数
            if(StringUtil.isNotBlank(queryRequest.getKeyword())){
                ps.setObject(1,"%" + queryRequest.getKeyword() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryPartByPage执行的SQL1:" + ps.toString());

            rs = ps.executeQuery();
            List<PartDO> list = new ArrayList<>();
            while (rs.next()){
                PartDO partDO= buildPart(rs);
                list.add(partDO);
            }
            tableResult.setData(list);

            /**查询总条数*/
            sb.setLength(0);
            sb.append("select count(*) from part where P_NAME like ?");
            ps = conn.prepareStatement(sb.toString());//预编译
            if(StringUtil.isNotBlank(queryRequest.getKeyword())){
                ps.setObject(1,"%" + queryRequest.getKeyword() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryPartByPage执行的SQL2:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()) {
                tableResult.setTotalCount(rs.getInt(1));
            }
            return tableResult;

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public PartDO getPartByP_PARTKEY(int P_PARTKEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        StringBuilder sb = new StringBuilder();
        sb.append("select P_PARTKEY, P_NAME, P_MFGR,P_BRAND,"+
                "P_TYPE,P_SIZE,P_CONTAINER,P_RETAILPRICE,P_COMMENT " +
                " from part where P_PARTKEY = ?");
        try {
            ps = conn.prepareStatement(sb.toString());//预编译
            ps.setObject(1, P_PARTKEY);
            //打印最终执行的SQL语句
            System.out.println("getPartByP_PARTKEY执行的SQL:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()){
                return buildPart(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public int updatePart(PartDO partDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("update part set P_NAME = ?, P_MFGR = ?,P_BRAND = ?,"+
                "P_TYPE = ?,P_SIZE = ?,P_CONTAINER = ?,P_RETAILPRICE = ?,P_COMMENT = ? " +
                " where P_PARTKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,partDO.getP_NAME());
            ps.setObject(2,partDO.getP_MFGR());
            ps.setObject(3,partDO.getP_BRAND());
            ps.setObject(4,partDO.getP_TYPE());
            ps.setObject(5,partDO.getP_SIZE());
            ps.setObject(6,partDO.getP_CONTAINER());
            ps.setObject(7,partDO.getP_RETAILPRICE());
            ps.setObject(8,partDO.getP_COMMENT());
            ps.setObject(9,partDO.getP_PARTKEY());
            //打印最终执行的SQL语句
            System.out.println("updatePart执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public int deletePart(int P_PARTKEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("delete from part where P_PARTKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,P_PARTKEY);
            //打印最终执行的SQL语句
            System.out.println("deletePart执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    //内部使用的函数
    private PartDO buildPart(ResultSet rs) throws SQLException {
        PartDO partDO = new PartDO();

        partDO.setP_PARTKEY(rs.getString("P_PARTKEY"));
        partDO.setP_NAME(rs.getString("P_NAME"));
        partDO.setP_MFGR(rs.getString("P_MFGR"));
        partDO.setP_BRAND(rs.getString("P_BRAND"));
        partDO.setP_TYPE(rs.getString("P_TYPE"));
        partDO.setP_SIZE(rs.getString("P_SIZE"));
        partDO.setP_CONTAINER(rs.getString("P_CONTAINER"));
        partDO.setP_RETAILPRICE(rs.getString("P_RETAILPRICE"));
        partDO.setP_COMMENT(rs.getString("P_COMMENT"));


        return partDO;
    }
}
