package com.company.dao.impl;

import com.company.beans.entity.AdminDO;
import com.company.beans.entity.CustomerDO;
import com.company.beans.req.CustomerRequest;
import com.company.beans.res.TableResult;
import com.company.dao.CustomerDao;
import com.company.util.DBUtil;
import com.company.util.StringUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerDaoImpl implements CustomerDao {
    @Override
    public int addCustomer(CustomerDO customerDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("insert into customer(C_CUSTKEY,C_NAME,C_ADDRESS,C_NATIONKEY,C_PHONE,C_ACCTBAL,C_MKTSEGMENT,C_COMMENT) ");
        sb.append("value(?,?,?,?,?,?,?,?)");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,customerDO.getC_CUSTKEY());
            ps.setObject(2,customerDO.getC_NAME());
            ps.setObject(3,customerDO.getC_ADDRESS());
            ps.setObject(4,customerDO.getC_NATIONKEY());
            ps.setObject(5,customerDO.getC_PHONE());
            ps.setObject(6,customerDO.getC_ACCTBAL());
            ps.setObject(7,customerDO.getC_MKTSEGMENT());
            ps.setObject(8,customerDO.getC_COMMENT());
            //打印最终执行的SQL语句
            System.out.println("addCustomer执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变函数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public TableResult<CustomerDO> queryCustomerByPage(CustomerRequest customerRequest) {
        TableResult<CustomerDO> tableResult = new TableResult<>();
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;

        /**页面查询*/
        StringBuilder sb = new StringBuilder();
        sb.append("select C_CUSTKEY,C_NAME,C_ADDRESS,C_NATIONKEY,C_PHONE,C_ACCTBAL,C_MKTSEGMENT,C_COMMENT ");
        sb.append("from customer where C_NAME like ? ");
        sb.append("order by C_CUSTKEY asc ");
        sb.append("limit " + customerRequest.getStart() + ", " + customerRequest.getPageSize());
        try {
            ps = conn.prepareStatement(sb.toString());//先预编译，再传参数
            if(StringUtil.isNotBlank(customerRequest.getCustomerName())){
                ps.setObject(1,"%" + customerRequest.getCustomerName() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryCustomerByPage执行的SQL1:" + ps.toString());

            rs = ps.executeQuery();
            List<CustomerDO> list = new ArrayList<>();
            while (rs.next()){
                CustomerDO customerDO= buildCustomer(rs);
                list.add(customerDO);
            }
            tableResult.setData(list);

            /**查询总条数*/
            sb.setLength(0);
            sb.append("select count(*) from customer where C_NAME like ?");
            ps = conn.prepareStatement(sb.toString());//预编译
            if(StringUtil.isNotBlank(customerRequest.getCustomerName())){
                ps.setObject(1,"%" + customerRequest.getCustomerName() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryCustomerByPage执行的SQL2:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()) {
                tableResult.setTotalCount(rs.getInt(1));
            }
            return tableResult;

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public CustomerDO getCustomerByC_CUSTKEY(int C_CUSTKEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        StringBuilder sb = new StringBuilder();
        sb.append("select C_CUSTKEY,C_NAME,C_ADDRESS,C_NATIONKEY,C_PHONE,C_ACCTBAL,C_MKTSEGMENT,C_COMMENT" +
                " from customer where C_CUSTKEY = ?");
        try {
            ps = conn.prepareStatement(sb.toString());//预编译
            ps.setObject(1, C_CUSTKEY);
            //打印最终执行的SQL语句
            System.out.println("getCustomerByC_CUSTKEY执行的SQL:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()){
                return buildCustomer(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public int updateCustomer(CustomerDO customerDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("update customer set C_NAME = ?,C_ADDRESS = ?,C_NATIONKEY = ?," +
                "C_PHONE = ?,C_ACCTBAL = ?,C_MKTSEGMENT = ?,C_COMMENT = ?" +
                " where C_CUSTKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,customerDO.getC_NAME());
            ps.setObject(2,customerDO.getC_ADDRESS());
            ps.setObject(3,customerDO.getC_NATIONKEY());
            ps.setObject(4,customerDO.getC_PHONE());
            ps.setObject(5,customerDO.getC_ACCTBAL());
            ps.setObject(6,customerDO.getC_MKTSEGMENT());
            ps.setObject(7,customerDO.getC_COMMENT());
            ps.setObject(8,customerDO.getC_CUSTKEY());
            //打印最终执行的SQL语句
            System.out.println("updateCustomer执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public int deleteCustomer(int C_CUSTKEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("delete from customer where C_CUSTKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,C_CUSTKEY);
            //打印最终执行的SQL语句
            System.out.println("deleteCustomer执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }


    //内部使用的函数
    private CustomerDO buildCustomer(ResultSet rs) throws SQLException {
        CustomerDO customerDO = new CustomerDO();
        customerDO.setC_CUSTKEY(rs.getInt("C_CUSTKEY"));
        customerDO.setC_NAME(rs.getString("C_NAME"));
        customerDO.setC_ADDRESS(rs.getString("C_ADDRESS"));
        customerDO.setC_NATIONKEY(rs.getInt("C_NATIONKEY"));
        customerDO.setC_PHONE(rs.getString("C_PHONE"));
        customerDO.setC_ACCTBAL(rs.getString("C_ACCTBAL"));
        customerDO.setC_MKTSEGMENT(rs.getString("C_MKTSEGMENT"));
        customerDO.setC_COMMENT(rs.getString("C_COMMENT"));

        return customerDO;
    }
}
