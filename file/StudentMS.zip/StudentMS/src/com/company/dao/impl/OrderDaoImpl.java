package com.company.dao.impl;

import com.company.beans.entity.OrderDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;
import com.company.dao.OrderDao;
import com.company.util.DBUtil;
import com.company.util.StringUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDaoImpl implements OrderDao {
    @Override
    public int addOrder(OrderDO orderDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("insert into orders(O_ORDERKEY, O_CUSTKEY, O_ORDERSTATUS,O_TOTALPRICE,"+
                "O_ORDDERDATE,O_ORDERPRIORITY,O_CLERK,0_SHIPPRIORITY,O_COMMENT ) ");
        sb.append("value(?,?,?,?,?,?,?,?,?)");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,orderDO.getO_ORDERKEY());
            ps.setObject(2,orderDO.getO_CUSTKEY());
            ps.setObject(3,orderDO.getO_ORDERSTATUS());
            ps.setObject(4,orderDO.getO_TOTALPRICE());
            ps.setObject(5,orderDO.getO_ORDDERDATE());
            ps.setObject(6,orderDO.getO_ORDERPRIORITY());
            ps.setObject(7,orderDO.getO_CLERK());
            ps.setObject(8,orderDO.getO_SHIPPRIORITY());
            ps.setObject(9,orderDO.getO_COMMENT());
            //打印最终执行的SQL语句
            System.out.println("addOrder执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变函数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public TableResult<OrderDO> queryOrderByPage(QueryRequest queryRequest) {
        TableResult<OrderDO> tableResult = new TableResult<>();
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;

        /**页面查询*/
        StringBuilder sb = new StringBuilder();
        sb.append("select O_ORDERKEY, O_CUSTKEY, O_ORDERSTATUS,O_TOTALPRICE," +
                "O_ORDDERDATE,O_ORDERPRIORITY,O_CLERK,0_SHIPPRIORITY,O_COMMENT ");
        sb.append("from orders where O_CUSTKEY like ? ");
        sb.append("order by O_ORDERKEY asc ");
        sb.append("limit " + queryRequest.getStart() + ", " + queryRequest.getPageSize());
        try {
            ps = conn.prepareStatement(sb.toString());//先预编译，再传参数
            if(StringUtil.isNotBlank(queryRequest.getKeyword())){
                ps.setObject(1,"%" + queryRequest.getKeyword() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryOrderByPage执行的SQL1:" + ps.toString());

            rs = ps.executeQuery();
            List<OrderDO> list = new ArrayList<>();
            while (rs.next()){
                OrderDO orderDO= buildOrder(rs);
                list.add(orderDO);
            }
            tableResult.setData(list);

            /**查询总条数*/
            sb.setLength(0);
            sb.append("select count(*) from orders where O_CUSTKEY like ?");
            ps = conn.prepareStatement(sb.toString());//预编译
            if(StringUtil.isNotBlank(queryRequest.getKeyword())){
                ps.setObject(1,"%" + queryRequest.getKeyword() + "%");
            }
            else{
                ps.setObject(1,"%");
            }

            //打印最终执行的SQL语句
            System.out.println("queryOrderByPage执行的SQL2:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()) {
                tableResult.setTotalCount(rs.getInt(1));
            }
            return tableResult;

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public OrderDO getOrderByO_ORDERKEY(int O_ORDERKEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return null;
        }
        PreparedStatement ps = null;
        ResultSet rs = null;
        StringBuilder sb = new StringBuilder();
        sb.append("select O_ORDERKEY, O_CUSTKEY, O_ORDERSTATUS,O_TOTALPRICE," +
                "O_ORDDERDATE,O_ORDERPRIORITY,O_CLERK,0_SHIPPRIORITY,O_COMMENT" +
                " from orders where O_ORDERKEY = ?");
        try {
            ps = conn.prepareStatement(sb.toString());//预编译
            ps.setObject(1, O_ORDERKEY);
            //打印最终执行的SQL语句
            System.out.println("getOrderByO_ORDERKEY执行的SQL:" + ps.toString());

            rs = ps.executeQuery();
            if(rs.next()){
                return buildOrder(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return null;
    }

    @Override
    public int updateOrder(OrderDO orderDO) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("update orders set O_CUSTKEY = ?, O_ORDERSTATUS = ?,O_TOTALPRICE = ?,O_ORDDERDATE = ?" +
                ",O_ORDERPRIORITY = ?,O_CLERK = ?,0_SHIPPRIORITY = ?,O_COMMENT = ?" +
                " where O_ORDERKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,orderDO.getO_CUSTKEY());
            ps.setObject(2,orderDO.getO_ORDERSTATUS());
            ps.setObject(3,orderDO.getO_TOTALPRICE());
            ps.setObject(4,orderDO.getO_ORDDERDATE());
            ps.setObject(5,orderDO.getO_ORDERPRIORITY());
            ps.setObject(6,orderDO.getO_CLERK());
            ps.setObject(7,orderDO.getO_SHIPPRIORITY());
            ps.setObject(8,orderDO.getO_COMMENT());
            ps.setObject(9,orderDO.getO_ORDERKEY());
            //打印最终执行的SQL语句
            System.out.println("updateOrder执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    @Override
    public int deleteOrder(int O_ORDERKEY) {
        Connection conn = DBUtil.getConn();
        if(conn == null){
            return 0;
        }
        PreparedStatement ps = null;
        StringBuilder sb = new StringBuilder();
        sb.append("delete from orders where O_ORDERKEY = ?");

        try {
            ps = conn.prepareStatement(sb.toString());
            ps.setObject(1,O_ORDERKEY);
            //打印最终执行的SQL语句
            System.out.println("deleteOrder执行的SQL:" + ps.toString());

            return ps.executeUpdate();//返回改变条数
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBUtil.closePs(ps);
            DBUtil.closeConn(conn);
        }
        return 0;
    }

    //内部使用的函数
    private OrderDO buildOrder(ResultSet rs) throws SQLException {
        OrderDO orderDO = new OrderDO();

        orderDO.setO_ORDERKEY(rs.getString("O_ORDERKEY"));
        orderDO.setO_CUSTKEY(rs.getString("O_CUSTKEY"));
        orderDO.setO_ORDERSTATUS(rs.getString("O_ORDERSTATUS"));
        orderDO.setO_TOTALPRICE(rs.getString("O_TOTALPRICE"));
        orderDO.setO_ORDDERDATE(rs.getString("O_ORDDERDATE"));
        orderDO.setO_ORDERPRIORITY(rs.getString("O_ORDERPRIORITY"));
        orderDO.setO_CLERK(rs.getString("O_CLERK"));
        orderDO.setO_SHIPPRIORITY(rs.getString("0_SHIPPRIORITY"));
        orderDO.setO_COMMENT(rs.getString("O_COMMENT"));

        return orderDO;
    }
}
