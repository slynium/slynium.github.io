package com.company.dao;

import com.company.beans.entity.AdminDO;

public interface AdminDao {
    AdminDO validateLogin(String userName);
}
