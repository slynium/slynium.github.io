package com.company.dao;

import com.company.beans.entity.PartDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;

public interface PartDao {
    int addPart(PartDO partDO);

    //分页查询国籍
    TableResult<PartDO> queryPartByPage(QueryRequest queryRequest);

    PartDO getPartByP_PARTKEY(int P_PARTKEY);

    int updatePart(PartDO partDO);
    int deletePart(int P_PARTKEY);
}
