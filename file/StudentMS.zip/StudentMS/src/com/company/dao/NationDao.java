package com.company.dao;

import com.company.beans.entity.CustomerDO;
import com.company.beans.entity.NationDO;
import com.company.beans.req.CustomerRequest;
import com.company.beans.req.NationRequest;
import com.company.beans.res.TableResult;

public interface NationDao {
    int addNation(NationDO nationDO);

    //分页查询国籍
    TableResult<NationDO> queryNationByPage(NationRequest nationRequest);

    NationDO getNationByN_NATIONKEY(int N_NATIONKEY);

    int updateNation(NationDO nationDO);
    int deleteNation(int N_NATIONEY);
}
