package com.company.dao;

import com.company.beans.entity.LineitemDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;

public interface LineitemDao {
    int addLineitem(LineitemDO lineitemDO);

    //分页查询国籍
    TableResult<LineitemDO> queryLineitemByPage(QueryRequest queryRequest);

    LineitemDO getLineitemByL_ORDERKEYAndL_LINENUMBER(int L_ORDERKEY,int L_LINENUMBER);

    int updateLineitem(LineitemDO lineitemDO);
    int deleteLineitem(int L_ORDERKEY, int L_LINENUMBER);

    TableResult<LineitemDO> queryLineitemL_ORDERKEY(int L_ORDERKEY);
}
