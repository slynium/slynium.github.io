package com.company.dao;

import com.company.beans.entity.PartsuppDO;
import com.company.beans.entity.SupplierDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;

public interface PartsuppDao {
    int addPartsupp(PartsuppDO partsuppDO);

    //分页查询国籍
    TableResult<PartsuppDO> queryPartsuppByPage(QueryRequest queryRequest);

    PartsuppDO getPartsuppByPS_PARTKEYAndPS_SUPPKEY(int PS_PARTKEY,int PS_SUPPKEY);

    int updatePartsupp(PartsuppDO partsuppDO);
    int deletePartsupp(int PS_PARTKEY, int PS_SUPPKEY);
}
