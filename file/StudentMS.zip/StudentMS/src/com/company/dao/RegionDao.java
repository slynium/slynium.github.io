package com.company.dao;

import com.company.beans.entity.NationDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.NationRequest;
import com.company.beans.req.QueryRequest;
import com.company.beans.req.RegionRequest;
import com.company.beans.res.TableResult;

public interface RegionDao {
    int addRegion(RegionDO regionDO);

    //分页查询国籍
    TableResult<RegionDO> queryRegionByPage(QueryRequest queryRequest);

    RegionDO getRegionByR_REGIONKEY(int R_REGIONKEY);

    int updateRegion(RegionDO regionDO);
    int deleteRegion(int R_REGIONKEY);
}
