package com.company.dao;

import com.company.beans.entity.OrderDO;
import com.company.beans.entity.RegionDO;
import com.company.beans.req.QueryRequest;
import com.company.beans.res.TableResult;

public interface OrderDao {
    int addOrder(OrderDO orderDO);

    //分页查询国籍
    TableResult<OrderDO> queryOrderByPage(QueryRequest queryRequest);

    OrderDO getOrderByO_ORDERKEY(int O_ORDERKEY);

    int updateOrder(OrderDO orderDO);
    int deleteOrder(int O_ORDERKEY);
}
