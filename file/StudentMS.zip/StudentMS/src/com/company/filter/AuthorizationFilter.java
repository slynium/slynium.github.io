package com.company.filter;

import com.company.beans.entity.AdminDO;
import com.company.util.Constants;
import com.company.util.ExcludeResourceUtil;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 *授权管理（必须通过login进入的才放行）
 * */

@WebFilter(filterName = "AuthorizationFilter"
        ,urlPatterns = {"/*"}
)
public class AuthorizationFilter implements Filter {


    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;

        //过滤器排除静态资源
        String requestURI = httpServletRequest.getRequestURI();
        System.out.println(requestURI);
        if (ExcludeResourceUtil.shouldExclude(requestURI)){
            //静态直接放行
            filterChain.doFilter(servletRequest,servletResponse);
        }
        else {
            HttpSession session = httpServletRequest.getSession();
            AdminDO adminDO = (AdminDO) session.getAttribute("adminDO");

            //截取http://localhost:8080/StudentMS_war_exploded/LoginServlet,"/LoginServlet"部分
            String contextPath = httpServletRequest.getContextPath();
            String path = requestURI.substring(contextPath.length());
            if(adminDO == null){
                if(path.equals("/LoginServlet")){
                    filterChain.doFilter(servletRequest,servletResponse);
                }
                else{


                    //跳转到登录界面
                    httpServletRequest.getRequestDispatcher("/WEB-INF/login.jsp")
                            .forward(httpServletRequest, httpServletResponse);
                }
            }
            else{
                filterChain.doFilter(servletRequest,servletResponse);
            }
        }
    }

    @Override
    public void destroy() {

    }
}
