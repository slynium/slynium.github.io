package com.company.filter;

import com.company.util.Constants;
import com.company.util.ExcludeResourceUtil;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter(filterName = "characterEncodingFilter"
        ,urlPatterns = {"/*"},
        initParams = {
            @WebInitParam(name = Constants.ENCODING,value = "UTF-8")
        }
)
public class CharacterEncodingFilter implements Filter {
    private String ENCODING = null;

    //初始化时回调
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        this.ENCODING = filterConfig.getInitParameter(Constants.ENCODING);
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        HttpServletResponse httpServletResponse = (HttpServletResponse) servletResponse;
//        System.out.println("当前req编码:" + httpServletRequest.getCharacterEncoding());
//        System.out.println("当前resp编码:" + httpServletResponse.getCharacterEncoding());

        //过滤器排除静态资源
        String requestURI = httpServletRequest.getRequestURI();
        System.out.println(requestURI);
        if (ExcludeResourceUtil.shouldExclude(requestURI)){
            //静态直接放行
            filterChain.doFilter(servletRequest,servletResponse);
        }
        else {
            //设置字符编码后再放行
            httpServletRequest.setCharacterEncoding(ENCODING);
            httpServletResponse.setCharacterEncoding(ENCODING);
            filterChain.doFilter(servletRequest, servletResponse);
        }
    }

    @Override
    public void destroy() {

    }
}
