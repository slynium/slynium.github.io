package com.company.beans.req;

import com.company.util.Constants;

public class NationRequest {
    private int pageNow ;//当前页数
    private int pageSize = Constants.PAGE_SIZE;//每页展示默认5条
    private String nationName;//查询关键词；

    public int getStart(){
        return (pageNow - 1) * pageSize;
    }

    public int getPageNow() {
        return pageNow;
    }

    public void setPageNow(int pageNow) {
        this.pageNow = pageNow;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String getNationName() {
        return nationName;
    }

    public void setNationName(String nationName) {
        this.nationName = nationName;
    }
}
