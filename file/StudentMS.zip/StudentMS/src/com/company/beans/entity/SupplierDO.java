package com.company.beans.entity;

public class SupplierDO {
    String S_SUPPKEY;
    String S_NAME;
    String S_ADDRESS;
    String S_NATIONKEY;
    String S_PHONE;
    String S_ACCTBAL;
    String S_COMMENT;

    public String getS_SUPPKEY() {
        return S_SUPPKEY;
    }

    public void setS_SUPPKEY(String s_SUPPKEY) {
        S_SUPPKEY = s_SUPPKEY;
    }

    public String getS_NAME() {
        return S_NAME;
    }

    public void setS_NAME(String s_NAME) {
        S_NAME = s_NAME;
    }

    public String getS_ADDRESS() {
        return S_ADDRESS;
    }

    public void setS_ADDRESS(String s_ADDRESS) {
        S_ADDRESS = s_ADDRESS;
    }

    public String getS_NATIONKEY() {
        return S_NATIONKEY;
    }

    public void setS_NATIONKEY(String s_NATIONKEY) {
        S_NATIONKEY = s_NATIONKEY;
    }

    public String getS_PHONE() {
        return S_PHONE;
    }

    public void setS_PHONE(String s_PHONE) {
        S_PHONE = s_PHONE;
    }

    public String getS_ACCTBAL() {
        return S_ACCTBAL;
    }

    public void setS_ACCTBAL(String s_ACCTBAL) {
        S_ACCTBAL = s_ACCTBAL;
    }

    public String getS_COMMENT() {
        return S_COMMENT;
    }

    public void setS_COMMENT(String s_COMMENT) {
        S_COMMENT = s_COMMENT;
    }
}