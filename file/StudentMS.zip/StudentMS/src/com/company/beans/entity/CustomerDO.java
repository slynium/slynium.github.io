package com.company.beans.entity;

/**
 * admin数据对象(data object)
 * 对应users表
 * */
public class CustomerDO {
    private int C_CUSTKEY;
    private String C_NAME;
    private String C_ADDRESS;
    private int C_NATIONKEY;
    private String C_PHONE;
    private String C_ACCTBAL;
    private String C_MKTSEGMENT;
    private String C_COMMENT;

    public int getC_CUSTKEY() {
        return C_CUSTKEY;
    }

    public void setC_CUSTKEY(int c_CUSTKEY) {
        C_CUSTKEY = c_CUSTKEY;
    }

    public String getC_NAME() {
        return C_NAME;
    }

    public void setC_NAME(String c_NAME) {
        C_NAME = c_NAME;
    }

    public String getC_ADDRESS() {
        return C_ADDRESS;
    }

    public void setC_ADDRESS(String c_ADDRESS) {
        C_ADDRESS = c_ADDRESS;
    }

    public int getC_NATIONKEY() {
        return C_NATIONKEY;
    }

    public void setC_NATIONKEY(int c_NATIONKEY) {
        C_NATIONKEY = c_NATIONKEY;
    }

    public String getC_PHONE() {
        return C_PHONE;
    }

    public void setC_PHONE(String c_PHONE) {
        C_PHONE = c_PHONE;
    }

    public String getC_ACCTBAL() {
        return C_ACCTBAL;
    }

    public void setC_ACCTBAL(String c_ACCTBAL) {
        C_ACCTBAL = c_ACCTBAL;
    }

    public String getC_MKTSEGMENT() {
        return C_MKTSEGMENT;
    }

    public void setC_MKTSEGMENT(String c_MKTSEGMENT) {
        C_MKTSEGMENT = c_MKTSEGMENT;
    }

    public String getC_COMMENT() {
        return C_COMMENT;
    }

    public void setC_COMMENT(String c_COMMENT) {
        C_COMMENT = c_COMMENT;
    }



}
