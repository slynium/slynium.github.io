package com.company.beans.entity;

public class OrderDO {
    String O_ORDERKEY;
    String O_CUSTKEY;
    String O_ORDERSTATUS;
    String O_TOTALPRICE;
    String O_ORDDERDATE;
    String O_ORDERPRIORITY;
    String O_CLERK;
    String O_SHIPPRIORITY;
    String O_COMMENT;

    public String getO_ORDERKEY() {
        return O_ORDERKEY;
    }

    public void setO_ORDERKEY(String o_ORDERKEY) {
        O_ORDERKEY = o_ORDERKEY;
    }

    public String getO_CUSTKEY() {
        return O_CUSTKEY;
    }

    public void setO_CUSTKEY(String o_CUSTKEY) {
        O_CUSTKEY = o_CUSTKEY;
    }

    public String getO_ORDERSTATUS() {
        return O_ORDERSTATUS;
    }

    public void setO_ORDERSTATUS(String o_ORDERSTATUS) {
        O_ORDERSTATUS = o_ORDERSTATUS;
    }

    public String getO_TOTALPRICE() {
        return O_TOTALPRICE;
    }

    public void setO_TOTALPRICE(String o_TOTALPRICE) {
        O_TOTALPRICE = o_TOTALPRICE;
    }

    public String getO_ORDDERDATE() {
        return O_ORDDERDATE;
    }

    public void setO_ORDDERDATE(String o_ORDDERDATE) {
        O_ORDDERDATE = o_ORDDERDATE;
    }

    public String getO_ORDERPRIORITY() {
        return O_ORDERPRIORITY;
    }

    public void setO_ORDERPRIORITY(String o_ORDERPRIORITY) {
        O_ORDERPRIORITY = o_ORDERPRIORITY;
    }

    public String getO_CLERK() {
        return O_CLERK;
    }

    public void setO_CLERK(String o_CLERK) {
        O_CLERK = o_CLERK;
    }

    public String getO_SHIPPRIORITY() {
        return O_SHIPPRIORITY;
    }

    public void setO_SHIPPRIORITY(String o_SHIPPRIORITY) {
        O_SHIPPRIORITY = o_SHIPPRIORITY;
    }

    public String getO_COMMENT() {
        return O_COMMENT;
    }

    public void setO_COMMENT(String o_COMMENT) {
        O_COMMENT = o_COMMENT;
    }
}
