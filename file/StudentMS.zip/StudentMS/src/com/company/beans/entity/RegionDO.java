package com.company.beans.entity;

public class RegionDO {
    String R_REGIONKEY;
    String R_NAME;
    String R_COMMENT;
    String PS_SUPPLYCOST;
    String PS_COMMENT;

    public String getR_REGIONKEY() {
        return R_REGIONKEY;
    }

    public void setR_REGIONKEY(String r_REGIONKEY) {
        R_REGIONKEY = r_REGIONKEY;
    }

    public String getR_NAME() {
        return R_NAME;
    }

    public void setR_NAME(String r_NAME) {
        R_NAME = r_NAME;
    }

    public String getR_COMMENT() {
        return R_COMMENT;
    }

    public void setR_COMMENT(String r_COMMENT) {
        R_COMMENT = r_COMMENT;
    }

    public String getPS_SUPPLYCOST() {
        return PS_SUPPLYCOST;
    }

    public void setPS_SUPPLYCOST(String PS_SUPPLYCOST) {
        this.PS_SUPPLYCOST = PS_SUPPLYCOST;
    }

    public String getPS_COMMENT() {
        return PS_COMMENT;
    }

    public void setPS_COMMENT(String PS_COMMENT) {
        this.PS_COMMENT = PS_COMMENT;
    }
}
