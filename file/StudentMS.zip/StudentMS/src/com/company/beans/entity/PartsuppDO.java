package com.company.beans.entity;

public class PartsuppDO {
    String PS_PARTKEY;
    String PS_SUPPKEY;
    String PS_AVAILQTY;
    String PS_SUPPLYCOST;
    String PS_COMMENT;

    public String getPS_PARTKEY() {
        return PS_PARTKEY;
    }

    public void setPS_PARTKEY(String PS_PARTKEY) {
        this.PS_PARTKEY = PS_PARTKEY;
    }

    public String getPS_SUPPKEY() {
        return PS_SUPPKEY;
    }

    public void setPS_SUPPKEY(String PS_SUPPKEY) {
        this.PS_SUPPKEY = PS_SUPPKEY;
    }

    public String getPS_AVAILQTY() {
        return PS_AVAILQTY;
    }

    public void setPS_AVAILQTY(String PS_AVAILQTY) {
        this.PS_AVAILQTY = PS_AVAILQTY;
    }

    public String getPS_SUPPLYCOST() {
        return PS_SUPPLYCOST;
    }

    public void setPS_SUPPLYCOST(String PS_SUPPLYCOST) {
        this.PS_SUPPLYCOST = PS_SUPPLYCOST;
    }

    public String getPS_COMMENT() {
        return PS_COMMENT;
    }

    public void setPS_COMMENT(String PS_COMMENT) {
        this.PS_COMMENT = PS_COMMENT;
    }
}
