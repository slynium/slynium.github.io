package com.company.beans.entity;

public class PartDO {
    String P_PARTKEY;
    String P_NAME;
    String P_MFGR;
    String P_BRAND;
    String P_TYPE;
    String P_SIZE;
    String P_CONTAINER;
    String P_RETAILPRICE;
    String P_COMMENT;

    public String getP_PARTKEY() {
        return P_PARTKEY;
    }

    public void setP_PARTKEY(String p_PARTKEY) {
        P_PARTKEY = p_PARTKEY;
    }

    public String getP_NAME() {
        return P_NAME;
    }

    public void setP_NAME(String p_NAME) {
        P_NAME = p_NAME;
    }

    public String getP_MFGR() {
        return P_MFGR;
    }

    public void setP_MFGR(String p_MFGR) {
        P_MFGR = p_MFGR;
    }

    public String getP_BRAND() {
        return P_BRAND;
    }

    public void setP_BRAND(String p_BRAND) {
        P_BRAND = p_BRAND;
    }

    public String getP_TYPE() {
        return P_TYPE;
    }

    public void setP_TYPE(String p_TYPE) {
        P_TYPE = p_TYPE;
    }

    public String getP_SIZE() {
        return P_SIZE;
    }

    public void setP_SIZE(String p_SIZE) {
        P_SIZE = p_SIZE;
    }

    public String getP_CONTAINER() {
        return P_CONTAINER;
    }

    public void setP_CONTAINER(String p_CONTAINER) {
        P_CONTAINER = p_CONTAINER;
    }

    public String getP_RETAILPRICE() {
        return P_RETAILPRICE;
    }

    public void setP_RETAILPRICE(String p_RETAILPRICE) {
        P_RETAILPRICE = p_RETAILPRICE;
    }

    public String getP_COMMENT() {
        return P_COMMENT;
    }

    public void setP_COMMENT(String p_COMMENT) {
        P_COMMENT = p_COMMENT;
    }
}
