package com.company.beans.entity;

public class NationDO {
    String N_NATIONKEY;
    String N_NAME;
    String N_REGIONKEY;
    String N_COMMENT;

    public String getN_NATIONKEY() {
        return N_NATIONKEY;
    }

    public void setN_NATIONKEY(String n_NATIONKEY) {
        N_NATIONKEY = n_NATIONKEY;
    }

    public String getN_NAME() {
        return N_NAME;
    }

    public void setN_NAME(String n_NAME) {
        N_NAME = n_NAME;
    }

    public String getN_REGIONKEY() {
        return N_REGIONKEY;
    }

    public void setN_REGIONKEY(String n_REGIONKEY) {
        N_REGIONKEY = n_REGIONKEY;
    }

    public String getN_COMMENT() {
        return N_COMMENT;
    }

    public void setN_COMMENT(String n_COMMENT) {
        N_COMMENT = n_COMMENT;
    }
}
