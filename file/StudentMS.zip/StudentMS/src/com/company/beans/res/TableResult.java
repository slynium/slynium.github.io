package com.company.beans.res;

import com.company.beans.entity.CustomerDO;
import com.company.util.Constants;

import java.util.List;

public class TableResult<T> {
    private List<T> data;
    private int totalCount;//总条数
    private int pageNow;//透传
    private String keyWord;//透传


    public int getPageCount(){
        int pageCount;
        if((totalCount % Constants.PAGE_SIZE == 0)){
            pageCount = totalCount / Constants.PAGE_SIZE;
        }
        else {
            pageCount = totalCount / Constants.PAGE_SIZE + 1;
        }
        return pageCount;
    }

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> data) {
        this.data = data;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getPageNow() {
        return pageNow;
    }

    public void setPageNow(int pageNow) {
        this.pageNow = pageNow;
    }

    public String getKeyWord() {
        return keyWord;
    }

    public void setKeyWord(String keyWord) {
        this.keyWord = keyWord;
    }
}
