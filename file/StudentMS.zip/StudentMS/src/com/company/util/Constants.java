package com.company.util;

public class Constants {
    public static final Integer PAGE_SIZE = 5;//共同参数，每页显示条数
    public static final String ENCODING = "ENCODING";
}
