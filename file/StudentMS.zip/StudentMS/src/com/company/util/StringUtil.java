package com.company.util;

public class StringUtil {
    public static boolean isNotBlank(String str){
        if(str != null && !str.trim().equals("")){
            return true;
        }
        else{
            return false;
        }
    }
}
