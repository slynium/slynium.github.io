package com.company.util;

/**过滤器排除1静态资源url*/

public class ExcludeResourceUtil {
    static String[] urls = {".js",".css",".ico",".jpg",".png"};
    public static boolean shouldExclude(String uri){
        boolean flag = false;
        for(String str : urls){
            if(uri.contains(str)){
                flag = true;
                break;
            }
        }
        return flag;
    }
}
